# HF-WSTGuard — CIFAR-10 / ResNet18 formal release (trigger=2.5)

This repository package contains the **locked formal experiment code** used for the CIFAR-10 / ResNet18 HF-WSTGuard paper line with DBA `trigger_value=2.5`.

## What is included

```text
Waffle-main/src/                     Core source code
notebooks/01_main/                   Main experiments, Seeds 44/55/66
notebooks/02_baselines/              Multi-Krum / FoolsGold / FLAME
notebooks/03_detector_ablation/      Detection-only ablations
notebooks/04_e2e_ablation/           End-to-end core ablations (SHAPEFIX)
notebooks/05_merge/                  Three-seed result merging
scripts/                             Dataset preparation / environment check
tools/analysis/                      HDBSCAN internal-data extraction
tools/visualization/                 Paper-figure export scripts
docs/                                Locked protocol
results/README.md                    Expected locked paper targets
```

## Formal protocol

The locked configuration is summarized in `docs/FORMAL_PROTOCOL_TRIGGER_2P5.md`.

Core settings: CIFAR-10, ResNet18, 100 clients, Dirichlet alpha=0.3, 10% malicious, 15% poisoning, DBA4, target=0, trigger size=3, **trigger value=2.5**, 300 rounds, R1–20 shared attack warmup, WST J=2/L=6, TopK=10%, Direction-Energy feature, global HDBSCAN, RiskFedAvg risk ceiling=0.95.

## Recommended run order

1. Prepare CIFAR-10 PNG data or use the exact prepared paper asset.
2. Run `notebooks/01_main/` for Seeds 44/55/66.
3. Save the main outputs because the baseline and E2E notebooks reuse the exact corresponding Round-20 checkpoint.
4. Run `notebooks/02_baselines/`.
5. Run `notebooks/03_detector_ablation/`.
6. Run `notebooks/04_e2e_ablation/` using the matching main Seed output.
7. Use `notebooks/05_merge/` to create three-seed mean ± sample-std tables.

## Kaggle note

The formal notebooks search for a project directory named `Waffle-main` containing `src/data/cifar10.py`. This release therefore keeps the source tree under `Waffle-main/`.

When creating a Kaggle Dataset from this repository, preserve the `Waffle-main/` subdirectory.

## Data

CIFAR-10 image bytes are not included. Run:

```bash
python scripts/prepare_cifar10_png.py
```

The formal paper runs used a prepared CIFAR-10 PNG asset. Exact client partitions can depend on the input file ordering, so use the same prepared asset for exact locked-result reproduction when available.

## Files deliberately excluded

- Model checkpoints (`.pt`, `.pth`)
- Result ZIPs and logs
- MNIST cross-dataset experiments
- Later legal-range `trigger_value=1.0` validation experiments
- Old LeNet experiments
- Deprecated class-conditional / pseudo-label / KMeans / voting branches
- Broken pre-SHAPEFIX E2E notebooks
- Superseded baseline notebooks

## Locked reference results

Main Seeds 44/55/66:

| Method | Clean Accuracy | ASR |
|---|---:|---:|
| FedAvg-Clean | 85.05 ± 1.88% | 1.98 ± 1.42% |
| FedAvg-Attack | 85.78 ± 1.91% | 100.00 ± 0.00% |
| HF-WSTGuard + RiskFedAvg | 85.49 ± 0.62% | 4.02 ± 0.64% |
| Oracle | 85.32 ± 1.27% | 1.48 ± 1.12% |

Pooled detector confusion: `TP=30, FP=0, TN=270, FN=0`.

Baseline means:

- Multi-Krum: 81.89 ± 2.42% Clean / 100.00 ± 0.00% ASR
- FoolsGold: 83.69 ± 2.94% Clean / 100.00 ± 0.00% ASR
- FLAME: 58.10 ± 1.20% Clean / 99.36 ± 0.75% ASR

## Reproducibility note

The code release intentionally preserves the formal trigger=2.5 protocol. The separate in-range trigger=1.0 study is a later robustness/validity audit and should not be mixed into this release.
