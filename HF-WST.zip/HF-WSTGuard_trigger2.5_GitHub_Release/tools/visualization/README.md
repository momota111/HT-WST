# CIFAR-10 DBA 输入与真实 WST 响应导出包

## 依据当前正式代码锁定的参数

- DBA trigger_size = 3
- DBA trigger_value = 2.5
- DBA partitions = 4
- target_label = 0
- WST J = 2
- WST L = 6
- high band = 移除 0-based 0–12，保留 13–48 共 36 通道
- CIFAR-10 输入 = ToTensor + Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
- WST 图像不使用 RandomCrop / HorizontalFlip

## 触发器位置

脚本不手写位置，而是直接调用当前 `DistributedBadNets._fragment_slices()`。

对于 32×32 且 trigger_size=3，当前代码会导出：

- sub-trigger 1 / partition 0：左上角
- sub-trigger 2 / partition 1：右上角
- sub-trigger 3 / partition 2：左下角
- sub-trigger 4 / partition 3：右下角
- global trigger：四个分片并集

## WST 响应图是什么

正式 detector 的单样本 high-band WST 是 36 通道空间张量。

论文图中的 2D 热力图定义为：

`response(u,v) = mean_k H_k(u,v), k = 13..48`

这只是对真实 high-band 中间响应的可视化汇总，不替代正式 detector 的最终特征。

同时脚本还导出正式单样本响应：

`36D = adaptive_max_pool2d(high_36ch, (1,1))`

以及：

`sample_energy_score = mean(36D)`

便于审计。

## 为什么输入 PNG 中 trigger 看起来是白色

当前攻击在 **Normalize后的张量空间** 将触发位置直接设为 2.5。

WST 使用的是未裁剪的真实 normalized tensor，因此仍然看到 2.5。

PNG 只是论文显示：
`x_display = clamp(x_norm*0.5 + 0.5, 0, 1)`

所以显示时会饱和到白色；这不改变 WST 计算。

## Kaggle 使用

推荐打开：

`export_cifar10_dba_wst_real_KAGGLE.ipynb`

Add Input：
- 你的 Riskfedavg / Waffle-main

然后 Run All。

如果没有完整 Waffle-main，也可将 `src(4).zip` 加入 Kaggle Input，脚本会尝试自动构建临时 src 工程。

## 输出

`/kaggle/working/figure2_cifar10_dba_wst_real_export/`

包含：

- `01_inputs/`：6张真实输入
- `02_wst_response_maps/`：6张真实WST响应 + shared colorbar
- `03_raw_arrays/`：normalized inputs、36ch high-band WST、2D响应、正式36D MaxPool
- `04_paper_figures/`：PNG/PDF/SVG 2×6总图
- `05_audit/metadata.json`
- `05_audit/trigger_coordinates.csv`
- `05_audit/wst_summary.csv`
- `FIG2_CIFAR10_DBA_WST_REAL_EXPORT.zip`

内嵌源图：
- filename = x16_y5.png
- SHA256 = d5cf810058295aee0f700742b1776dda889d1062a3c4f5c5d5915998c5940fe1
