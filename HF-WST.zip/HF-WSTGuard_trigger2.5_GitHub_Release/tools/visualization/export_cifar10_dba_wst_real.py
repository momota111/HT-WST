from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
import matplotlib.pyplot as plt

# ======================================================================================
# 0. 正式协议：来自当前 ResNet18 + HF-WSTGuard Seed44 主实验
# ======================================================================================

TARGET_LABEL = 0
TRIGGER_SIZE = 3
TRIGGER_VALUE = 2.5
NUM_PARTITIONS = 4

J_WST = 2
L_WST = 6

# CIFAR-10 正式加载：ToTensor + Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
NORM_MEAN = (0.5, 0.5, 0.5)
NORM_STD = (0.5, 0.5, 0.5)

# 论文图响应图定义：
# 对单张输入的 WST 输出，按正式 high-band 规则移除 0..12，
# 保留 13..48 共 36 通道，然后“逐位置跨通道求均值”得到 2D 可视化图。
#
# 注意：这张 2D 图是对正式 high-band 中间张量的可视化汇总，
# 不是替代正式 detector 的最终 36-D client feature。
RESPONSE_SUMMARY = "channel_mean_over_retained_high_band_before_client_topk_aggregation"

VARIANT_ORDER = [
    "clean",
    "subtrigger_1",
    "subtrigger_2",
    "subtrigger_3",
    "subtrigger_4",
    "global_trigger",
]

VARIANT_LABELS = {
    "clean": "Clean",
    "subtrigger_1": "Sub-trigger 1",
    "subtrigger_2": "Sub-trigger 2",
    "subtrigger_3": "Sub-trigger 3",
    "subtrigger_4": "Sub-trigger 4",
    "global_trigger": "Global trigger",
}

# 与用户论文图中当前使用的同一真实 CIFAR-10 样本一致：x16_y5
EMBEDDED_SAMPLE_FILENAME = "x16_y5.png"
EMBEDDED_SAMPLE_LABEL = 5
EMBEDDED_SAMPLE_SHA256 = "d5cf810058295aee0f700742b1776dda889d1062a3c4f5c5d5915998c5940fe1"
EMBEDDED_SAMPLE_B64 = """iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAJyElEQVR4nB1WSW+d13l+z/DNd76X5OUgkaI4SJRkOhatpkUXbQ0jSBN408FAgTboskCQP9A/0E2BdlOgCZBtNgECtIs2CRoUSZShsR1HEh2KpGTxcrjz9M3fmd7i+qwPzvOeF89EvvH1DzQBDaiNYZxRCozZNg8AgTmwd3D34f0dSGeQa17fuA7n5x/9RmZpoaShVBr86c8+eXV+7VnuSsl3Uc3TNNEq0qq5sfav3/n3dx5/iUspFUGNaBC1Qc44okYT3lppHb39YG93w7HxpHMWDsKdP1x7/6tfrbtu97Ofe1T5QSUHe3h1GU4m87maJoZpkMYShBpCO1fdf/6nf/mHb36LG2MMQQQAQACKyPM839tZfe9o285GL3/8sZR5c3u78uAI/aqk7N6DB9n1s+jqBGZdQ/0nt6q33Ecfn/TPOlNNKBAOaCiiBXh+dnH6pscNpUA000gMaCQxqjurla8cbQViMu0OWRaqLJ4O6gdvv++sbGeJ8IKyv3T31fGJnAy7o8gCiwEcbPi1kn18NpjHiIQbIgnqMNcXmea25xZGc6Q2hWrFXV+uHm61vHyKReJbVqqlMsjBMkAt20lyIRgsbe3WV9ZH04nO9CiRjXpJpOOGGzy+v/HJyU0vig1BDShT9j9PT3itXkuFJmju3mo+3mku4TyZXI8S6To0HoZhFGFQW9m6X19ZQ0rAGAFAS+XyUivuuEu1yiAah4W2DY9Hg1qzfbDdSs/iQaYNcBRZ7/kn3LK4I+RKwzm6Uw+SUa9/LQqZKXYxS8U8qS559vJK+95Dt9LMCwlo4kwIaWzXQ0aCml9PxXA4WyqXueUmybzmNdv12iAdIXE5znT/Y+4HvObYT/bbVtTvXffG8zRJs1q99upiYqH0V6rtW3v1tU1ltBJpnkZxWhiZRdP51WV/GgpDuFZS4YImQiFkkWdzTi0JDmBMseDVKt9qVGwVvT57FUWSMRcI1ZRMRLHUcCqry9t7D/MkG3cuVZ7mEnNkxhSzSXTTDfujdG2jXSApjLYYTVNlVKo0ASgANKLgaPhGo7Rcsq+Pz7vdMRI3CBxljOXYGtArlUul0vnxbyN1dvLydbnk7z54ZJUbnh202netcr2BpNHwricwiYv1sqvyVDMWprkyKSFAwQAhfLNVwvk4D9OiINThmVCUA7cZVzoeJ1edUaimz0+7g/Hs6MljPwhKrbpl28HRH3QHg+e/+JFlE7CsSVys+B7RplJvyrSnAC1gBMAgcKZSUAUYZMwxhuWF8jiVSoEFIaWth4//+J0/unN8Pu526616udWsLjW5RbBpv/9XH7oeTi5PV4Xz2bNTZdD3PGQsziQBlwIhoAkQHo+GATLOXUJT1NoASAlCYr1ZL93eXz14QkrLmwfu7f39oBQ0mi3bscFgWghTL7/13lfe/H6tk/yK0rOFnzn85fVNlEpKiCSpBYyBw1HrMEm541LOiZKUUKNQCb19Z8vf2MzzHAArlQrn1PO8UqlEKTVSqqLIpPSD+vLGjoBPhAal9TSOepMZQYsthEZgsSVO3dbtqDCU255jc4LEGKKhSIXnuYSaKJ4Z1K5rW5altV4YFoIxYGlBwzFOxzXHW1vdINzNiDXKVWYIAbAQGFgAnADl/sYBuxkbFQW+I7MMJRoNSZRW14gXeIXIsyx2OEdE3w8oo4QwBSqbDocvPx30J9PCbLTqD946PDv+eJATQ2yGmhFqFiiLy5zU2iv3Hg5Pz0uGGSDhJNOAmUiYE2zu7Ma2zzgDIF4QeIEPhGmj0/ng9MVH4cXrbmd83ulVt+8efvnRRb9TDEIE0IQSIGThz5QQwnMNV1AJ7r1b73VAfCrDAigSYy2ttFdXVydS+TbzbGbbFkHMs0QUIkvSOCp+9+zs9OTzTOi9ldb2o/vb+3v969Fw2NdgCCwwNEimGbe94FUeRJPZn7bXqHfuenNERdzq+t6u4wfqpj8cXy2vbkxmU8/zfN/P87wQktvlaaLmhfCrZbdUMkpv3blzsXU1nk0ePXz41jtvM8t68eL3Lz/9jHt+kEHVZnj79nI2vEnTVOTx6r396uaOoG6t0S5yQQjNk9l0NKjXGwhmMhxc3lxzz93Yvc1sO80zCuSdx4+zTC01Gn/799/YeXBg+e54Fn73375Dnj47+d7POh8ern/54VpSJK9fPAvn0639fbe5IhUyskg7jZjEce/mqn9zo4SYT0eDq2uZJgYVsazW6ubt3QO/UtHKRHG+srpabtS4Y2dG9a4GvDOMW559sL3MfL9aLR3+yZ9JKUUh5SLVjTGmKAqFC17Xmy1OoH99Y4IqWSe6yJIotINgfftOc2WZMyryLJdf8N22CCVUG893+fnleKdqByULGQNEYwCBEMoI5xRRFQVQrhaAQhSFKASlzLYd3wsUZahNUKmsr6/XlpaN1rOJBp04nNqMKNQMkQPh05x9cC+wiDJk4YDSaKVQKCMVCqlEUSithRRxkox63Um/Z4QUmZzPpiJLsyQ6bLdX2227VE2SmBDi2JyCoYBaFloohy/Cgd6qMoMLiWqllDKFgkIaJWQhCvXF5JPRsH99Fc6mWhZpFHc+v7y6vGaEPHrr/t3dXUqoKEQcxfPpLEsyCkABOGWIAgD4rTL1UWokfLGQPC+kXPwDtdFGqywJx6PBuNcTSWryfDgcnJ6+vLy43Fjf/Ou//Ivt7XYUhd3LS+KWwnAezWfAHW7ZlDOKixID1PDbnhSCWUWGtq8WbwpEoIBJFs2n48mgH04nKsuHvf75+aurq+soisvl2gdf+/O3D3bOTj5KCyloMMsELGSYttY3FWpltO15tlhIkq+TeRiqIJgFfhkIkaJIkmg2n04nk2Q2i8fj4eXly7PXFzf9IlNaUSGN0fmzZ6eDm77DZansj8JoOE+zNE2S8Gt37zMNKJTSJkuSPM15lYso1vHFm2U/KJg3m4yHvev5eDTr9nqdTv/yMpnOevNsHqsoyufzNC8Kjer583NCaaXqba63ms1WdzidTWeMYqPeUk/ynXv7wPmgN3z681/zmZQ+psk0lAxKS20yG6mrTu/F8fDNG89mB+2ms7fzi+M3x09/OwsXoa5BInBqFok7GM964z4BYgAZMEbhf3/yk6N333W84FWn8+tf/d9/fv8/yD/+3d98+PX3CGFxOq+UKpXAj2bjYX8wn8Su6/q15i+fv/z2937QnSaLTohoQAAgAb6QCxhCLbqwfgBCjFa+yw+/dHh4dMgc/t8//K/PP3vDh5kw5YbDCFFxlE6Zpe2qu1pab61oRH4zSX/404/6swQXBkwMQQOwKOOgvmCjQ9H6ovAuDqW2VPD0l7/53YvjRqs+Gg0Dt/z/kwg7o7lyFyEAAAAASUVORK5CYII="""


# ======================================================================================
# 1. 环境 / 工程定位
# ======================================================================================

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_kymatio(allow_install: bool = True) -> None:
    if importlib.util.find_spec("kymatio") is not None:
        print("[依赖OK] kymatio")
        return

    if not allow_install:
        raise RuntimeError(
            "当前环境缺少 kymatio。Kaggle 中请打开 Internet 后安装：pip install kymatio"
        )

    print("[安装依赖] kymatio")
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", "-q", "kymatio"]
    )


def _is_project_root(p: Path) -> bool:
    return (
        (p / "src" / "data" / "attacks.py").is_file()
        and (p / "src" / "domains" / "wavelet.py").is_file()
    )


def find_project_root(explicit: str | None, working_dir: Path) -> Path:
    candidates: list[Path] = []

    if explicit:
        candidates.append(Path(explicit))

    env_root = os.environ.get("HF_WSTGUARD_ROOT")
    if env_root:
        candidates.append(Path(env_root))

    candidates.extend([
        Path.cwd(),
        working_dir / "Waffle-main",
        Path("/kaggle/working/Waffle-main"),
    ])

    for p in candidates:
        try:
            if _is_project_root(p):
                return p.resolve()
        except Exception:
            pass

    # Kaggle Input 中自动找 Waffle-main
    kaggle_input = Path("/kaggle/input")
    if kaggle_input.is_dir():
        roots = []
        for marker in kaggle_input.rglob("src/data/attacks.py"):
            root = marker.parent.parent.parent
            if _is_project_root(root):
                roots.append(root.resolve())
        if roots:
            # 优先目录名 Waffle-main
            roots = sorted(
                set(roots),
                key=lambda x: (x.name != "Waffle-main", len(str(x))),
            )
            return roots[0]

    # 兜底：若用户只上传了 src*.zip，则自动解压成临时工程
    zip_candidates = []
    for search_root in [Path.cwd(), Path("/kaggle/input"), working_dir]:
        if not search_root.exists():
            continue
        for z in search_root.rglob("*.zip"):
            low = z.name.lower()
            if "src" in low:
                zip_candidates.append(z)

    for z in zip_candidates:
        tmp_root = working_dir / "_figure2_temp_project"
        src_root = tmp_root / "src"
        if tmp_root.exists():
            shutil.rmtree(tmp_root)
        src_root.mkdir(parents=True, exist_ok=True)

        try:
            with zipfile.ZipFile(z, "r") as zf:
                names = zf.namelist()
                # 当前 src(4).zip 的内部根目录直接是 data/, domains/, ...
                zf.extractall(src_root)

            if _is_project_root(tmp_root):
                print("[工程定位] 从 src ZIP 构建临时工程：", z)
                return tmp_root.resolve()
        except Exception:
            continue

    raise FileNotFoundError(
        "没有找到包含 src/data/attacks.py 与 src/domains/wavelet.py 的工程。\n"
        "Kaggle 请 Add Input：Riskfedavg/Waffle-main，或上传 src(4).zip。"
    )


# ======================================================================================
# 2. 固定同一原始 CIFAR-10 图像
# ======================================================================================

def write_embedded_sample(dst: Path) -> Path:
    dst.parent.mkdir(parents=True, exist_ok=True)
    raw = base64.b64decode(EMBEDDED_SAMPLE_B64.encode("ascii"))
    dst.write_bytes(raw)

    actual = sha256_file(dst)
    if actual != EMBEDDED_SAMPLE_SHA256:
        raise RuntimeError(
            f"内嵌源图 SHA 不一致：{actual} != {EMBEDDED_SAMPLE_SHA256}"
        )
    return dst


def locate_source_image(
    explicit: str | None,
    project_root: Path,
    out_dir: Path,
) -> tuple[Path, str]:
    if explicit:
        p = Path(explicit)
        if not p.is_file():
            raise FileNotFoundError(f"--source-image 不存在：{p}")
        return p.resolve(), "explicit_path"

    # 优先找工程中同名原始样本
    exact_names = {
        "x16_y5.png",
        "x16_y5(1).png",
        "x16_y5 (1).png",
    }

    roots = [
        project_root / "data" / "cifar10",
        Path("/kaggle/input"),
        Path.cwd(),
    ]
    for root in roots:
        if not root.exists():
            continue
        for p in root.rglob("*.png"):
            if p.name in exact_names:
                return p.resolve(), "project_or_kaggle_exact_name"

    # 保证复现论文当前版式中的同一张真实 32x32 图
    embedded = out_dir / "_source" / EMBEDDED_SAMPLE_FILENAME
    write_embedded_sample(embedded)
    return embedded.resolve(), "embedded_exact_user_sample"


def pil_to_normalized_tensor(img: Image.Image) -> torch.Tensor:
    """
    精确对应 src/data/cifar10.py：
      ToTensor()
      Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
    """
    img = img.convert("RGB")
    arr = np.asarray(img, dtype=np.float32) / 255.0
    x = torch.from_numpy(arr).permute(2, 0, 1).contiguous()

    mean = torch.tensor(NORM_MEAN, dtype=x.dtype).view(3, 1, 1)
    std = torch.tensor(NORM_STD, dtype=x.dtype).view(3, 1, 1)
    return (x - mean) / std


def normalized_tensor_to_display(x: torch.Tensor) -> np.ndarray:
    """
    只用于 PNG/论文显示。
    正式 WST 输入绝不经过这里的 clip。
    """
    mean = torch.tensor(NORM_MEAN, dtype=x.dtype, device=x.device).view(3, 1, 1)
    std = torch.tensor(NORM_STD, dtype=x.dtype, device=x.device).view(3, 1, 1)

    display = x * std + mean
    display = display.clamp(0.0, 1.0)
    return display.detach().cpu().permute(1, 2, 0).numpy()


# ======================================================================================
# 3. 按现有 src 的真实 DBA 代码生成 4 子触发器 + 完整触发器
# ======================================================================================

def build_variants(clean_x: torch.Tensor):
    from src.data.attacks import DistributedBadNets, make_dba_global_attack

    attacks: dict[str, Any] = {}
    variants: dict[str, torch.Tensor] = {"clean": clean_x.clone()}

    for pid in range(NUM_PARTITIONS):
        attack = DistributedBadNets(
            target_label=TARGET_LABEL,
            partition_id=pid,
            trigger_size=TRIGGER_SIZE,
            trigger_value=TRIGGER_VALUE,
            num_partitions=NUM_PARTITIONS,
            global_trigger=False,
        )
        name = f"subtrigger_{pid + 1}"
        attacks[name] = attack
        variants[name] = attack(clean_x.clone())

    global_attack = make_dba_global_attack(
        target_label=TARGET_LABEL,
        trigger_size=TRIGGER_SIZE,
        trigger_value=TRIGGER_VALUE,
        num_partitions=NUM_PARTITIONS,
    )
    attacks["global_trigger"] = global_attack
    variants["global_trigger"] = global_attack(clean_x.clone())

    return variants, attacks


def slice_to_pair(s: slice, length: int) -> list[int]:
    start = 0 if s.start is None else int(s.start)
    stop = length if s.stop is None else int(s.stop)
    return [start, stop]


def trigger_coordinate_rows(attacks: dict[str, Any], h: int, w: int):
    rows = []
    for pid in range(NUM_PARTITIONS):
        attack = attacks[f"subtrigger_{pid + 1}"]
        ys, xs = attack._fragment_slices(h, w, pid)
        rows.append({
            "partition_id_zero_based": pid,
            "figure_name": f"subtrigger_{pid + 1}",
            "y_slice_half_open": slice_to_pair(ys, h),
            "x_slice_half_open": slice_to_pair(xs, w),
            "pixel_rows_inclusive": [
                slice_to_pair(ys, h)[0],
                slice_to_pair(ys, h)[1] - 1,
            ],
            "pixel_cols_inclusive": [
                slice_to_pair(xs, w)[0],
                slice_to_pair(xs, w)[1] - 1,
            ],
            "trigger_size": TRIGGER_SIZE,
            "trigger_value_normalized": TRIGGER_VALUE,
        })
    return rows


# ======================================================================================
# 4. 真实 WST：复用 src/domains/wavelet.py 的 _to_gray 和 _select_wst_band
# ======================================================================================

def compute_real_wst(
    variants: dict[str, torch.Tensor],
    device: str,
):
    from src.domains import wavelet as wavelet_mod

    if not hasattr(wavelet_mod, "_to_gray"):
        raise RuntimeError("src/domains/wavelet.py 缺少 _to_gray")
    if not hasattr(wavelet_mod, "_select_wst_band"):
        raise RuntimeError("src/domains/wavelet.py 缺少 _select_wst_band")
    if not hasattr(wavelet_mod, "Scattering2D"):
        raise RuntimeError("src/domains/wavelet.py 缺少 Scattering2D")

    # 全部变体同尺寸，只构造一个 Scattering2D
    sample = variants["clean"]
    h, w = int(sample.shape[-2]), int(sample.shape[-1])

    scattering = wavelet_mod.Scattering2D(
        J=J_WST,
        L=L_WST,
        shape=(h, w),
    ).to(device)

    out = {}

    for name in VARIANT_ORDER:
        x = variants[name].unsqueeze(0)  # [1,3,H,W]

        # 正式检测同一灰度转换
        gray = wavelet_mod._to_gray(x).float().to(device)  # [1,H,W]

        with torch.no_grad():
            sx_full = scattering(gray.contiguous())
            sx_high = wavelet_mod._select_wst_band(
                sx_full,
                J_wst=J_WST,
                L_wst=L_WST,
                band="high",
            )

        # 正式配置 J=2,L=6 时：
        # full = 49 channels, high = channels 13..48 = 36 channels.
        if sx_high.ndim != 4:
            raise RuntimeError(
                f"{name}: 预期 high WST 为 [N,C,H,W]，实际 {tuple(sx_high.shape)}"
            )
        if int(sx_high.shape[1]) != 36:
            raise RuntimeError(
                f"{name}: high WST 应为36通道，实际 {int(sx_high.shape[1])}。"
                "请检查 Kymatio / J / L / _select_wst_band。"
            )

        # 论文图 2D 响应：
        # 对保留的36通道在每个空间位置求均值。
        response_map = sx_high[0].mean(dim=0)

        # 同时导出正式 detector 单样本排序分数对应量：
        # adaptive maxpool each channel -> mean over 36 channels.
        formal_36d = F.adaptive_max_pool2d(
            sx_high,
            (1, 1),
        ).view(-1)
        sample_energy_score = formal_36d.mean()

        out[name] = {
            "gray_input": gray[0].detach().cpu(),
            "wst_full": sx_full[0].detach().cpu(),
            "wst_high_36ch": sx_high[0].detach().cpu(),
            "response_map": response_map.detach().cpu(),
            "formal_single_image_36d_maxpool": formal_36d.detach().cpu(),
            "formal_sample_energy_score": float(sample_energy_score.item()),
        }

    return out


# ======================================================================================
# 5. 保存真实输入 / 数组 / 统一色标图
# ======================================================================================

def save_png_exact(arr01: np.ndarray, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    arr8 = np.clip(np.rint(arr01 * 255.0), 0, 255).astype(np.uint8)
    Image.fromarray(arr8, mode="RGB").save(path)


def save_outputs(
    source_path: Path,
    source_mode: str,
    clean_img: Image.Image,
    variants: dict[str, torch.Tensor],
    attacks: dict[str, Any],
    wst: dict[str, dict[str, Any]],
    out_dir: Path,
    project_root: Path,
    device: str,
):
    inputs_dir = out_dir / "01_inputs"
    response_dir = out_dir / "02_wst_response_maps"
    arrays_dir = out_dir / "03_raw_arrays"
    figures_dir = out_dir / "04_paper_figures"
    audit_dir = out_dir / "05_audit"

    for d in [inputs_dir, response_dir, arrays_dir, figures_dir, audit_dir]:
        d.mkdir(parents=True, exist_ok=True)

    # ---------- 输入图 ----------
    normalized_inputs_npz = {}
    display_inputs = {}

    for name in VARIANT_ORDER:
        x = variants[name]
        display = normalized_tensor_to_display(x)
        display_inputs[name] = display
        normalized_inputs_npz[name] = x.detach().cpu().numpy()

        save_png_exact(
            display,
            inputs_dir / f"{name}.png",
        )

    np.savez_compressed(
        arrays_dir / "normalized_inputs_exact.npz",
        **normalized_inputs_npz,
    )

    # ---------- WST 数组 ----------
    response_npz = {}
    high_npz = {}
    formal_36d_npz = {}
    summary_rows = []

    for name in VARIANT_ORDER:
        resp = wst[name]["response_map"].numpy()
        high = wst[name]["wst_high_36ch"].numpy()
        f36 = wst[name]["formal_single_image_36d_maxpool"].numpy()

        response_npz[name] = resp
        high_npz[name] = high
        formal_36d_npz[name] = f36

        summary_rows.append({
            "variant": name,
            "formal_sample_energy_score": wst[name]["formal_sample_energy_score"],
            "response_min": float(resp.min()),
            "response_max": float(resp.max()),
            "response_mean": float(resp.mean()),
            "wst_full_channels": int(wst[name]["wst_full"].shape[0]),
            "wst_high_channels": int(high.shape[0]),
            "wst_response_h": int(resp.shape[0]),
            "wst_response_w": int(resp.shape[1]),
        })

    np.savez_compressed(
        arrays_dir / "wst_response_maps_channel_mean.npz",
        **response_npz,
    )
    np.savez_compressed(
        arrays_dir / "wst_high_36channels_exact.npz",
        **high_npz,
    )
    np.savez_compressed(
        arrays_dir / "formal_single_image_36d_maxpool.npz",
        **formal_36d_npz,
    )

    # ---------- 共享色标 ----------
    all_response_values = np.concatenate(
        [response_npz[n].reshape(-1) for n in VARIANT_ORDER]
    )
    shared_vmin = float(all_response_values.min())
    shared_vmax = float(all_response_values.max())

    if not np.isfinite(shared_vmin) or not np.isfinite(shared_vmax):
        raise FloatingPointError("WST response 包含 NaN/Inf")
    if shared_vmax <= shared_vmin:
        shared_vmax = shared_vmin + 1e-12

    # 单独响应图：所有文件共享完全相同的 vmin/vmax。
    for name in VARIANT_ORDER:
        fig, ax = plt.subplots(figsize=(2.2, 2.2))
        im = ax.imshow(
            response_npz[name],
            vmin=shared_vmin,
            vmax=shared_vmax,
            interpolation="nearest",
        )
        ax.set_axis_off()
        fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
        fig.savefig(
            response_dir / f"{name}_wst_response.png",
            dpi=600,
            bbox_inches="tight",
            pad_inches=0,
        )
        plt.close(fig)

    # 共享 colorbar 独立导出，方便填论文模板。
    fig, ax = plt.subplots(figsize=(1.0, 4.2))
    ax.set_visible(False)
    sm = plt.cm.ScalarMappable(
        norm=plt.Normalize(shared_vmin, shared_vmax)
    )
    cbar = fig.colorbar(sm, ax=ax, fraction=0.45)
    cbar.ax.tick_params(labelsize=8)
    cbar.set_label("WST response", fontsize=9)
    fig.savefig(
        response_dir / "shared_colorbar.png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.04,
    )
    plt.close(fig)

    # ---------- 2×6 总图 ----------
    fig, axes = plt.subplots(
        2,
        6,
        figsize=(14.8, 5.6),
        constrained_layout=True,
    )

    last_im = None
    for j, name in enumerate(VARIANT_ORDER):
        axes[0, j].imshow(
            display_inputs[name],
            interpolation="nearest",
        )
        axes[0, j].set_title(VARIANT_LABELS[name], fontsize=10)
        axes[0, j].set_axis_off()

        last_im = axes[1, j].imshow(
            response_npz[name],
            vmin=shared_vmin,
            vmax=shared_vmax,
            interpolation="nearest",
        )
        axes[1, j].set_axis_off()

    axes[0, 0].set_ylabel("Input", fontsize=10)
    axes[1, 0].set_ylabel("High-band WST", fontsize=10)

    cbar = fig.colorbar(
        last_im,
        ax=axes.ravel().tolist(),
        shrink=0.72,
        pad=0.012,
    )
    cbar.set_label("Shared WST response scale", fontsize=9)

    for ext in ("png", "pdf", "svg"):
        fig.savefig(
            figures_dir / f"figure2_real_dba_inputs_wst.{ext}",
            dpi=600 if ext == "png" else None,
            bbox_inches="tight",
        )
    plt.close(fig)

    # ---------- trigger 坐标 ----------
    h, w = clean_img.height, clean_img.width
    coord_rows = trigger_coordinate_rows(attacks, h, w)

    with (audit_dir / "trigger_coordinates.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as f:
        writer = csv.DictWriter(
            f,
            fieldnames=list(coord_rows[0].keys()),
        )
        writer.writeheader()
        for row in coord_rows:
            row = dict(row)
            row["y_slice_half_open"] = json.dumps(row["y_slice_half_open"])
            row["x_slice_half_open"] = json.dumps(row["x_slice_half_open"])
            row["pixel_rows_inclusive"] = json.dumps(row["pixel_rows_inclusive"])
            row["pixel_cols_inclusive"] = json.dumps(row["pixel_cols_inclusive"])
            writer.writerow(row)

    # ---------- WST summary ----------
    with (audit_dir / "wst_summary.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as f:
        writer = csv.DictWriter(
            f,
            fieldnames=list(summary_rows[0].keys()),
        )
        writer.writeheader()
        writer.writerows(summary_rows)

    # ---------- metadata ----------
    metadata = {
        "purpose": "paper_figure_real_DBA_inputs_and_real_WST_responses",
        "source_image": {
            "path_used": str(source_path),
            "source_mode": source_mode,
            "sha256": sha256_file(source_path),
            "embedded_reference_sha256": EMBEDDED_SAMPLE_SHA256,
            "filename_reference": EMBEDDED_SAMPLE_FILENAME,
            "label_from_filename": EMBEDDED_SAMPLE_LABEL,
            "size": [int(clean_img.width), int(clean_img.height)],
        },
        "project": {
            "project_root": str(project_root),
            "attacks_py": str(project_root / "src/data/attacks.py"),
            "wavelet_py": str(project_root / "src/domains/wavelet.py"),
        },
        "dba": {
            "target_label": TARGET_LABEL,
            "trigger_size": TRIGGER_SIZE,
            "trigger_value_normalized_space": TRIGGER_VALUE,
            "num_partitions": NUM_PARTITIONS,
            "subtrigger_partition_ids_zero_based": [0, 1, 2, 3],
            "global_trigger": "union of partition_id 0,1,2,3 using existing DistributedBadNets code",
            "coordinates": coord_rows,
        },
        "input_preprocessing": {
            "ToTensor": True,
            "Normalize_mean": list(NORM_MEAN),
            "Normalize_std": list(NORM_STD),
            "random_training_augmentation_used": False,
            "WST_input_uses_normalized_tensor_without_display_clipping": True,
            "display_only_denormalization": "x_display = clamp(x_norm*0.5 + 0.5, 0, 1)",
            "important": (
                "trigger_value=2.5 is applied in normalized tensor space; "
                "PNG display clips values to [0,1] only for visualization. "
                "WST always sees the unclipped normalized tensor."
            ),
        },
        "wst": {
            "J": J_WST,
            "L": L_WST,
            "gray_conversion": "reuse src.domains.wavelet._to_gray",
            "band_selection": "reuse src.domains.wavelet._select_wst_band(..., band='high')",
            "removed_channel_indices_zero_based": list(range(0, 13)),
            "retained_channel_indices_zero_based": list(range(13, 49)),
            "retained_channel_count": 36,
            "response_map_definition": RESPONSE_SUMMARY,
            "formal_single_image_score_definition": (
                "adaptive_max_pool2d(high_36ch,(1,1)) -> 36D -> channel mean"
            ),
            "shared_vmin": shared_vmin,
            "shared_vmax": shared_vmax,
            "device": device,
        },
        "figure_integrity": {
            "same_source_image_for_all_six_inputs": True,
            "same_retained_channel_set_for_all_six_responses": True,
            "same_vmin_vmax_for_all_six_responses": True,
            "response_images_are_real_WST_outputs": True,
            "interpolation": "nearest",
            "no_per_panel_normalization": True,
            "no_fake_heatmap": True,
        },
    }

    (audit_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 人类可读审计说明
    lines = [
        "FIGURE 2 REAL DATA / WST EXPORT AUDIT",
        "=" * 80,
        f"source_image = {source_path}",
        f"source_sha256 = {metadata['source_image']['sha256']}",
        f"source_mode = {source_mode}",
        "",
        f"trigger_size = {TRIGGER_SIZE}",
        f"trigger_value(normalized space) = {TRIGGER_VALUE}",
        f"partitions = {NUM_PARTITIONS}",
        "",
        f"WST J = {J_WST}",
        f"WST L = {L_WST}",
        "removed channels = 0..12",
        "retained channels = 13..48 (36 channels)",
        f"shared_vmin = {shared_vmin:.12g}",
        f"shared_vmax = {shared_vmax:.12g}",
        "",
        "Per-variant formal single-image high-frequency energy score:",
    ]
    for row in summary_rows:
        lines.append(
            f"  {row['variant']}: {row['formal_sample_energy_score']:.12g}"
        )

    (audit_dir / "AUDIT.txt").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )

    # ---------- 最终 ZIP ----------
    archive = shutil.make_archive(
        str(out_dir / "FIG2_CIFAR10_DBA_WST_REAL_EXPORT"),
        "zip",
        root_dir=out_dir,
        base_dir=None,
    )

    print("\n" + "=" * 96)
    print("REAL DBA INPUT + WST EXPORT COMPLETE")
    print("=" * 96)
    print("SOURCE        =", source_path)
    print("SOURCE_MODE   =", source_mode)
    print("SOURCE_SHA256 =", sha256_file(source_path))
    print("TRIGGER_SIZE  =", TRIGGER_SIZE)
    print("TRIGGER_VALUE =", TRIGGER_VALUE)
    print("WST           = J=2, L=6")
    print("HIGH BAND     = channels 13..48, total 36")
    print("SHARED_VMIN   =", shared_vmin)
    print("SHARED_VMAX   =", shared_vmax)
    print("OUTPUT_DIR    =", out_dir.resolve())
    print("ARCHIVE       =", archive)
    print("=" * 96)

    return Path(archive)


# ======================================================================================
# 6. Main
# ======================================================================================

def main():
    parser = argparse.ArgumentParser(
        description=(
            "Export real CIFAR-10 DBA clean/sub-trigger/global-trigger inputs "
            "and real WST high-band response maps using the existing HF-WSTGuard code."
        )
    )
    parser.add_argument(
        "--project-root",
        type=str,
        default=None,
        help="Waffle-main root. Omit to auto-detect.",
    )
    parser.add_argument(
        "--source-image",
        type=str,
        default=None,
        help=(
            "Optional exact source PNG. If omitted, search x16_y5.png; "
            "if still absent, use the embedded exact user-provided x16_y5 sample."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="/kaggle/working/figure2_cifar10_dba_wst_real_export",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda" if torch.cuda.is_available() else "cpu",
    )
    parser.add_argument(
        "--no-install",
        action="store_true",
        help="Do not auto-install kymatio.",
    )
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    ensure_kymatio(allow_install=not args.no_install)

    project_root = find_project_root(
        explicit=args.project_root,
        working_dir=Path("/kaggle/working")
        if Path("/kaggle/working").exists()
        else out_dir.parent,
    )

    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

    # 确保导入的是该 project root 的 src。
    os.environ["HF_WSTGUARD_ROOT"] = str(project_root)

    source_path, source_mode = locate_source_image(
        explicit=args.source_image,
        project_root=project_root,
        out_dir=out_dir,
    )

    clean_img = Image.open(source_path).convert("RGB")
    if clean_img.size != (32, 32):
        raise RuntimeError(
            f"论文当前样本应为32x32 CIFAR-10图像，实际={clean_img.size}"
        )

    clean_x = pil_to_normalized_tensor(clean_img)
    variants, attacks = build_variants(clean_x)

    # 几何/输入审计
    for name in VARIANT_ORDER:
        x = variants[name]
        if tuple(x.shape) != (3, 32, 32):
            raise RuntimeError(f"{name}: shape错误 {tuple(x.shape)}")
        if not torch.isfinite(x).all():
            raise FloatingPointError(f"{name}: 输入含NaN/Inf")

    wst = compute_real_wst(
        variants=variants,
        device=args.device,
    )

    save_outputs(
        source_path=source_path,
        source_mode=source_mode,
        clean_img=clean_img,
        variants=variants,
        attacks=attacks,
        wst=wst,
        out_dir=out_dir,
        project_root=project_root,
        device=args.device,
    )


if __name__ == "__main__":
    main()
