
from pathlib import Path
import json
import zipfile
import shutil

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

SEEDS = (44, 55, 66)
INPUT_ROOT = Path("/kaggle/input")
WORK_ROOT = Path("/kaggle/working/HF_WSTGuard_3Seed_HDBSCAN_REAL_DATA")
FIG_ROOT = Path("/kaggle/working/HF_WSTGuard_HDBSCAN_FIGURES_COMBINED")

WORK_ROOT.mkdir(parents=True, exist_ok=True)
FIG_ROOT.mkdir(parents=True, exist_ok=True)

def has_expected_layout(root: Path) -> bool:
    return all(
        (root / f"seed_{seed}" / "hdbscan_plot_data.csv").is_file()
        and (root / f"seed_{seed}" / "f_i_37d.npy").is_file()
        and (root / f"seed_{seed}" / "final_candidates.json").is_file()
        and (root / f"seed_{seed}" / "verification.json").is_file()
        for seed in SEEDS
    )

def locate_real_data_root() -> Path:
    for candidate in INPUT_ROOT.rglob("all_seeds_hdbscan_plot_data.csv"):
        root = candidate.parent
        if has_expected_layout(root):
            print("[DATA] Using already-exposed real-data directory:")
            print("      ", root)
            return root

    zip_candidates = list(INPUT_ROOT.rglob("*.zip"))
    valid_zips = []

    for zpath in zip_candidates:
        try:
            with zipfile.ZipFile(zpath, "r") as zf:
                names = set(zf.namelist())
                required = {
                    "all_seeds_hdbscan_plot_data.csv",
                    "seed_44/hdbscan_plot_data.csv",
                    "seed_44/f_i_37d.npy",
                    "seed_55/hdbscan_plot_data.csv",
                    "seed_55/f_i_37d.npy",
                    "seed_66/hdbscan_plot_data.csv",
                    "seed_66/f_i_37d.npy",
                }
                if required.issubset(names):
                    valid_zips.append(zpath)
        except zipfile.BadZipFile:
            pass

    if len(valid_zips) == 0:
        raise FileNotFoundError(
            "没有在 /kaggle/input 中找到 HF_WSTGuard_3Seed_HDBSCAN_REAL_DATA ZIP，"
            "也没有找到已展开的数据目录。请把处理好的真实数据 ZIP 作为 Kaggle Input 加入。"
        )

    zpath = sorted(valid_zips, key=lambda p: len(str(p)))[0]
    print("[DATA] Found ZIP:", zpath)

    if WORK_ROOT.exists():
        shutil.rmtree(WORK_ROOT)
    WORK_ROOT.mkdir(parents=True)

    with zipfile.ZipFile(zpath, "r") as zf:
        zf.extractall(WORK_ROOT)

    if not has_expected_layout(WORK_ROOT):
        raise RuntimeError("ZIP 解压后目录结构与预期不一致。")

    print("[DATA] Extracted to:", WORK_ROOT)
    return WORK_ROOT

DATA_ROOT = locate_real_data_root()

data = {}
all_f = []

for seed in SEEDS:
    seed_dir = DATA_ROOT / f"seed_{seed}"

    df = pd.read_csv(seed_dir / "hdbscan_plot_data.csv")
    f_i = np.load(seed_dir / "f_i_37d.npy")
    final_candidates = json.loads(
        (seed_dir / "final_candidates.json").read_text(encoding="utf-8")
    )
    verification = json.loads(
        (seed_dir / "verification.json").read_text(encoding="utf-8")
    )

    expected_cols = {
        "client_id",
        "z_i",
        "hdbscan_label",
        "is_noise",
        "is_final_candidate",
    }
    if not expected_cols.issubset(df.columns):
        raise ValueError(
            f"Seed {seed}: hdbscan_plot_data.csv 缺列："
            f"{expected_cols - set(df.columns)}"
        )

    if df.shape[0] != 100:
        raise ValueError(f"Seed {seed}: 应有100个客户端，实际={df.shape[0]}")

    if f_i.shape != (100, 37):
        raise ValueError(f"Seed {seed}: f_i 应为(100,37)，实际={f_i.shape}")

    if not np.isfinite(f_i).all():
        raise FloatingPointError(f"Seed {seed}: f_i 含 NaN/Inf")

    if not verification.get("all_cluster_sizes_match", False):
        raise RuntimeError(f"Seed {seed}: cluster size 核验未通过")

    if float(verification.get("max_abs_diff_cluster_mean_z", 1.0)) > 1e-10:
        raise RuntimeError(f"Seed {seed}: z_i 簇均值核验未通过")

    # 兼容旧字段名/新字段名
    candidate_key = "label_not_0_equals_final_candidates"
    if candidate_key not in verification:
        candidate_key = "label_not_0_equals_saved_final_candidates"

    if not verification.get(candidate_key, False):
        raise RuntimeError(f"Seed {seed}: final candidates 核验未通过")

    saved_candidates = sorted(map(int, final_candidates))
    csv_candidates = sorted(
        df.loc[df["is_final_candidate"].astype(bool), "client_id"]
        .astype(int)
        .tolist()
    )
    if saved_candidates != csv_candidates:
        raise RuntimeError(f"Seed {seed}: CSV 与 final_candidates.json 不一致")

    df = df.sort_values("client_id").reset_index(drop=True)

    data[seed] = {
        "df": df,
        "f_i": f_i,
        "final_candidates": saved_candidates,
        "verification": verification,
    }
    all_f.append(f_i)

    print(
        f"[PASS] Seed {seed}: "
        f"labels={df['hdbscan_label'].value_counts().sort_index().to_dict()} | "
        f"final_candidates={saved_candidates}"
    )

X_all = np.vstack(all_f)
display_pca = PCA(n_components=2, svd_solver="full")
display_pca.fit(X_all)

pca_metadata = {
    "rule": (
        "Concatenate real 37-D f_i from Seeds 44/55/66; fit one shared "
        "PCA(n_components=2, svd_solver='full'); use same basis for all seeds."
    ),
    "display_only": True,
    "used_by_hdbscan": False,
    "explained_variance_ratio": display_pca.explained_variance_ratio_.tolist(),
}
(FIG_ROOT / "display_pca_metadata.json").write_text(
    json.dumps(pca_metadata, ensure_ascii=False, indent=2),
    encoding="utf-8",
)

for seed in SEEDS:
    data[seed]["xy"] = display_pca.transform(data[seed]["f_i"])

all_z = np.concatenate([data[s]["df"]["z_i"].to_numpy() for s in SEEDS])
z_pad = 0.08 * max(all_z.max() - all_z.min(), 1e-12)
Z_LIM = (float(all_z.min() - z_pad), float(all_z.max() + z_pad))

all_xy = np.vstack([data[s]["xy"] for s in SEEDS])
x_pad = 0.08 * max(all_xy[:, 0].max() - all_xy[:, 0].min(), 1e-12)
y_pad = 0.08 * max(all_xy[:, 1].max() - all_xy[:, 1].min(), 1e-12)
X_LIM = (float(all_xy[:, 0].min() - x_pad), float(all_xy[:, 0].max() + x_pad))
Y_LIM = (float(all_xy[:, 1].min() - y_pad), float(all_xy[:, 1].max() + y_pad))

MARKERS = {-1: "x", 0: "o", 1: "^", 2: "s", 3: "D"}

def cluster_name(label: int) -> str:
    return "Noise (-1)" if label == -1 else f"Cluster {label}"

def plot_combined_z_figure():
    fig, axes = plt.subplots(1, 3, figsize=(18.5, 5.2), sharey=True)
    handles_all, labels_all = [], []

    for ax, seed in zip(axes, SEEDS):
        df = data[seed]["df"].copy()
        df = df.sort_values(["z_i", "client_id"], ascending=[False, True]).reset_index(drop=True)

        for label in sorted(df["hdbscan_label"].unique()):
            part = df[df["hdbscan_label"] == label]
            rank = part.index.to_numpy()
            sc = ax.scatter(
                rank,
                part["z_i"].to_numpy(),
                marker=MARKERS.get(int(label), "o"),
                s=40,
                label=cluster_name(int(label)),
            )
            if cluster_name(int(label)) not in labels_all:
                handles_all.append(sc)
                labels_all.append(cluster_name(int(label)))

        cand = df[df["is_final_candidate"].astype(bool)]
        sc2 = ax.scatter(
            cand.index.to_numpy(),
            cand["z_i"].to_numpy(),
            s=135,
            facecolors="none",
            edgecolors="black",
            linewidths=1.2,
            label="Final candidate",
        )
        if "Final candidate" not in labels_all:
            handles_all.append(sc2)
            labels_all.append("Final candidate")

        for rank, row in cand.iterrows():
            ax.annotate(
                f"C{int(row['client_id'])}",
                (rank, float(row["z_i"])),
                xytext=(0, 6),
                textcoords="offset points",
                ha="center",
                fontsize=7,
            )

        ax.axhline(0.0, linewidth=0.8, linestyle="--")
        ax.set_ylim(*Z_LIM)
        ax.set_xlabel(r"Clients sorted by $z_i$")
        ax.set_title(f"Seed {seed}")
        ax.grid(alpha=0.22, linestyle="--")

    axes[0].set_ylabel(r"Standardized log-energy $z_i$")
    fig.suptitle(
        r"Combined view of $z_i$, real HDBSCAN labels, and final candidates",
        y=0.98,
        fontsize=13,
    )
    fig.legend(
        handles_all, labels_all,
        loc="upper center",
        ncol=len(labels_all),
        frameon=True,
        bbox_to_anchor=(0.5, 0.92),
        fontsize=9,
    )
    fig.text(
        0.5,
        0.02,
        "Noise is label -1. Cluster IDs are HDBSCAN labels only and are not mapped "
        "to the four DBA sub-trigger partitions.",
        ha="center",
        fontsize=8.5,
    )
    fig.tight_layout(rect=(0.02, 0.07, 0.98, 0.88))
    for ext in ("png", "pdf", "svg"):
        fig.savefig(
            FIG_ROOT / f"combined_zi_hdbscan_candidates.{ext}",
            dpi=600 if ext == "png" else None,
            bbox_inches="tight",
        )
    plt.show()
    plt.close(fig)

def plot_combined_projection_figure():
    fig, axes = plt.subplots(1, 3, figsize=(18.0, 5.8), sharex=True, sharey=True)
    handles_all, labels_all = [], []

    for ax, seed in zip(axes, SEEDS):
        df = data[seed]["df"]
        xy = data[seed]["xy"]

        for label in sorted(df["hdbscan_label"].unique()):
            mask = df["hdbscan_label"].to_numpy() == label
            sc = ax.scatter(
                xy[mask, 0],
                xy[mask, 1],
                marker=MARKERS.get(int(label), "o"),
                s=45,
                label=cluster_name(int(label)),
            )
            if cluster_name(int(label)) not in labels_all:
                handles_all.append(sc)
                labels_all.append(cluster_name(int(label)))

        cand_mask = df["is_final_candidate"].astype(bool).to_numpy()
        sc2 = ax.scatter(
            xy[cand_mask, 0],
            xy[cand_mask, 1],
            s=140,
            facecolors="none",
            edgecolors="black",
            linewidths=1.2,
            label="Final candidate",
        )
        if "Final candidate" not in labels_all:
            handles_all.append(sc2)
            labels_all.append("Final candidate")

        for cid in df.loc[cand_mask, "client_id"].astype(int).tolist():
            ax.annotate(
                f"C{cid}",
                (xy[cid, 0], xy[cid, 1]),
                xytext=(4, 4),
                textcoords="offset points",
                fontsize=7,
            )

        ax.set_xlim(*X_LIM)
        ax.set_ylim(*Y_LIM)
        ax.set_title(f"Seed {seed}")
        ax.set_xlabel("Display PC1")
        ax.grid(alpha=0.22, linestyle="--")

    axes[0].set_ylabel("Display PC2")
    fig.suptitle(
        r"Shared 2-D projection of real 37-D $f_i$ (display only)",
        y=0.98,
        fontsize=13,
    )
    fig.legend(
        handles_all, labels_all,
        loc="upper center",
        ncol=len(labels_all),
        frameon=True,
        bbox_to_anchor=(0.5, 0.92),
        fontsize=9,
    )
    fig.text(
        0.5,
        0.02,
        "The same PCA basis is used for Seeds 44/55/66. "
        "This 2-D projection is for display only; HDBSCAN operates in the original 37-D space.",
        ha="center",
        fontsize=8.5,
    )
    fig.tight_layout(rect=(0.02, 0.07, 0.98, 0.88))
    for ext in ("png", "pdf", "svg"):
        fig.savefig(
            FIG_ROOT / f"combined_fi37_pca_display_only.{ext}",
            dpi=600 if ext == "png" else None,
            bbox_inches="tight",
        )
    plt.show()
    plt.close(fig)

plot_combined_z_figure()
plot_combined_projection_figure()

combined_rows = []
for seed in SEEDS:
    df = data[seed]["df"].copy()
    xy = data[seed]["xy"]
    df["display_pc1"] = xy[:, 0]
    df["display_pc2"] = xy[:, 1]
    df.insert(0, "seed", seed)
    combined_rows.append(df)

combined_plot_data = pd.concat(combined_rows, ignore_index=True)
combined_plot_data.to_csv(
    FIG_ROOT / "all_seeds_plotting_data_with_display_pca.csv",
    index=False,
    encoding="utf-8-sig",
)

archive = shutil.make_archive(
    "/kaggle/working/HF_WSTGuard_HDBSCAN_FIGURES_COMBINED",
    "zip",
    root_dir=FIG_ROOT,
)

print("\n" + "=" * 95)
print("COMBINED FIGURE EXPORT COMPLETE")
print("=" * 95)
print("DATA_ROOT =", DATA_ROOT)
print("FIG_ROOT  =", FIG_ROOT)
print("ARCHIVE   =", archive)
print("\nGenerated files:")
for p in sorted(FIG_ROOT.iterdir()):
    print(" -", p.name)
