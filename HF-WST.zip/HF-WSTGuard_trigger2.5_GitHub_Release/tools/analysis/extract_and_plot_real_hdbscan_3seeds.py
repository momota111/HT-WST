from __future__ import annotations

import argparse
import io
import json
import re
import shutil
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt
from sklearn.cluster import HDBSCAN
from sklearn.decomposition import PCA


SEEDS = (44, 55, 66)


def torch_load_bytes(raw: bytes):
    bio = io.BytesIO(raw)
    try:
        return torch.load(bio, map_location="cpu", weights_only=True)
    except TypeError:
        bio.seek(0)
        return torch.load(bio, map_location="cpu")


def find_seed_zip(input_root: Path, seed: int) -> Path:
    """
    按用户真实文件命名直接适配：
      resnet18-nopt-44*.zip
      resnet18-nopt-55*.zip
      resnet18-nopt-66*.zip
    同时兼容文件名里只出现 seed 数字但目录结构正确的 ZIP。
    """
    patterns = [
        re.compile(rf"resnet18[-_]nopt[-_]{seed}.*\.zip$", re.I),
        re.compile(rf".*{seed}.*\.zip$", re.I),
    ]

    zips = list(input_root.rglob("*.zip"))
    preferred = [p for p in zips if patterns[0].match(p.name)]
    if preferred:
        return sorted(preferred, key=lambda p: len(str(p)))[0]

    # 第二层：检查 ZIP 内真实结构，而不是只猜文件名。
    for p in sorted(zips, key=lambda x: len(str(x))):
        if not patterns[1].match(p.name):
            continue
        try:
            with zipfile.ZipFile(p, "r") as zf:
                names = set(zf.namelist())
                required = {
                    "config.json",
                    f"seed_{seed}/nolabel_wst_features.pt",
                    f"seed_{seed}/nolabel_detection_logs.json",
                    f"seed_{seed}/nolabel_detection_result.json",
                }
                if required.issubset(names):
                    return p
        except zipfile.BadZipFile:
            pass

    raise FileNotFoundError(
        f"没有找到 Seed{seed} 正式结果 ZIP。"
        f"需要包含 seed_{seed}/nolabel_wst_features.pt。"
    )


def read_json(zf: zipfile.ZipFile, name: str):
    return json.loads(zf.read(name).decode("utf-8"))


def reconstruct_seed(seed: int, zip_path: Path, out_root: Path):
    out = out_root / f"seed_{seed}"
    out.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as zf:
        names = set(zf.namelist())
        required = [
            "config.json",
            f"seed_{seed}/nolabel_wst_features.pt",
            f"seed_{seed}/nolabel_wst_metadata.json",
            f"seed_{seed}/nolabel_detection_logs.json",
            f"seed_{seed}/nolabel_detection_result.json",
            f"seed_{seed}/nolabel_detection_scores.csv",
        ]
        missing = [x for x in required if x not in names]
        if missing:
            raise RuntimeError(
                f"Seed{seed} ZIP 缺少正式文件：{missing}"
            )

        cfg = read_json(zf, "config.json")
        meta = read_json(zf, f"seed_{seed}/nolabel_wst_metadata.json")
        logs = read_json(zf, f"seed_{seed}/nolabel_detection_logs.json")
        det = read_json(zf, f"seed_{seed}/nolabel_detection_result.json")
        scores = pd.read_csv(
            io.BytesIO(
                zf.read(f"seed_{seed}/nolabel_detection_scores.csv")
            )
        )
        feature_tensor = torch_load_bytes(
            zf.read(f"seed_{seed}/nolabel_wst_features.pt")
        )

    # ------------------------------------------------------------------
    # A. 读取正式保存的 p_i
    # ------------------------------------------------------------------
    if not torch.is_tensor(feature_tensor):
        raise TypeError(
            f"Seed{seed}: nolabel_wst_features.pt 不是 Tensor"
        )

    feature_tensor = feature_tensor.detach().cpu().float()
    if tuple(feature_tensor.shape) != (100, 1, 36):
        raise ValueError(
            f"Seed{seed}: 期望 [100,1,36]，实际={tuple(feature_tensor.shape)}"
        )

    p_i = (
        feature_tensor[:, 0, :]
        .numpy()
        .astype(np.float64)
    )

    # ------------------------------------------------------------------
    # B. 按正式 detector 重建 z_i 与 37D f_i
    # detection_hdbscan.py:
    #   direction = X / ||X||
    #   log_energy = log1p(||X||)
    #   z = (log_energy-mean)/std
    #   [direction ; energy_weight*z]
    #   最终 L2 normalize
    # ------------------------------------------------------------------
    norms = np.maximum(
        np.linalg.norm(p_i, axis=1, keepdims=True),
        1e-12,
    )
    direction = p_i / norms

    e_i = np.log1p(norms)
    z_i = (
        e_i - e_i.mean()
    ) / (
        e_i.std() + 1e-12
    )

    energy_weight = float(cfg["energy_weight"])
    f_raw = np.concatenate(
        [
            direction,
            energy_weight * z_i,
        ],
        axis=1,
    )

    f_i = f_raw / np.maximum(
        np.linalg.norm(f_raw, axis=1, keepdims=True),
        1e-12,
    )

    if f_i.shape != (100, 37):
        raise RuntimeError(
            f"Seed{seed}: f_i 维度错误：{f_i.shape}"
        )

    # ------------------------------------------------------------------
    # C. 用正式 HDBSCAN 参数重新得到逐客户端 label
    # 保存日志明确 backend = sklearn.cluster.HDBSCAN
    # ------------------------------------------------------------------
    clusterer = HDBSCAN(
        min_cluster_size=int(cfg["min_cluster_size"]),
        min_samples=int(cfg["min_samples"]),
        metric=str(cfg["metric"]),
        cluster_selection_method="eom",
        allow_single_cluster=False,
    )
    labels = clusterer.fit_predict(f_i).astype(int)

    # ------------------------------------------------------------------
    # D. final candidates 绝不重猜，直接读正式保存结果
    # ------------------------------------------------------------------
    final_candidates = [
        int(x)
        for x in det["detected_ids"]
    ]
    final_candidate_set = set(final_candidates)

    # ------------------------------------------------------------------
    # E. 导出用户需要的四类真实文件
    # ------------------------------------------------------------------
    z_df = pd.DataFrame({
        "client_id": np.arange(100, dtype=int),
        "z_i": z_i[:, 0],
    })
    z_df.to_csv(
        out / "z_i.csv",
        index=False,
        encoding="utf-8-sig",
    )

    label_df = pd.DataFrame({
        "client_id": np.arange(100, dtype=int),
        "label": labels,
        "is_noise": labels == -1,
    })
    label_df.to_csv(
        out / "hdbscan_labels.csv",
        index=False,
        encoding="utf-8-sig",
    )

    (out / "final_candidates.json").write_text(
        json.dumps(
            final_candidates,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    np.save(
        out / "f_i_37d.npy",
        f_i,
    )
    np.save(
        out / "f_i_before_final_l2_37d.npy",
        f_raw,
    )
    np.save(
        out / "p_i_36d.npy",
        p_i,
    )

    f_cols = [
        f"f_{j:02d}"
        for j in range(37)
    ]
    f_df = pd.DataFrame(
        f_i,
        columns=f_cols,
    )
    f_df.insert(
        0,
        "client_id",
        np.arange(100, dtype=int),
    )
    f_df.to_csv(
        out / "f_i_37d.csv",
        index=False,
        encoding="utf-8-sig",
    )

    p_cols = [
        f"p_{j:02d}"
        for j in range(36)
    ]
    p_df = pd.DataFrame(
        p_i,
        columns=p_cols,
    )
    p_df.insert(
        0,
        "client_id",
        np.arange(100, dtype=int),
    )
    p_df.to_csv(
        out / "p_i_36d.csv",
        index=False,
        encoding="utf-8-sig",
    )

    plot_df = pd.DataFrame({
        "client_id": np.arange(100, dtype=int),
        "z_i": z_i[:, 0],
        "hdbscan_label": labels,
        "is_noise": labels == -1,
        "is_final_candidate": [
            i in final_candidate_set
            for i in range(100)
        ],
        # 仅用于事后核验/图注，不参与 detector。
        "is_malicious_posthoc": (
            scores["is_malicious"]
            .astype(bool)
            .to_numpy()
        ),
    })
    plot_df.to_csv(
        out / "hdbscan_plot_data.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ------------------------------------------------------------------
    # F. 与正式保存日志逐簇严格核验
    # ------------------------------------------------------------------
    recomputed_rows = []
    for lab in sorted(np.unique(labels).tolist()):
        mask = labels == lab
        recomputed_rows.append({
            "label": int(lab),
            "size": int(mask.sum()),
            "ratio": float(mask.mean()),
            "mean_energy_z": float(
                z_i[mask, 0].mean()
            ),
            "is_noise": bool(lab == -1),
        })

    recomputed_df = pd.DataFrame(
        recomputed_rows
    )
    recomputed_df.to_csv(
        out / "cluster_summary_recomputed.csv",
        index=False,
        encoding="utf-8-sig",
    )

    saved_infos = logs[0]["cluster_infos"]
    saved_by_label = {
        int(x["label"]): x
        for x in saved_infos
    }

    checks = []
    for row in recomputed_rows:
        lab = int(row["label"])
        saved = saved_by_label[lab]

        checks.append({
            "label": lab,
            "size_match": (
                int(row["size"])
                == int(saved["size"])
            ),
            "recomputed_size": int(row["size"]),
            "saved_size": int(saved["size"]),
            "recomputed_mean_energy_z": float(
                row["mean_energy_z"]
            ),
            "saved_mean_energy_z": float(
                saved["mean_energy_z"]
            ),
            "abs_diff_mean_energy_z": abs(
                float(row["mean_energy_z"])
                - float(saved["mean_energy_z"])
            ),
        })

    label_not_main_ids = (
        np.where(labels != 0)[0]
        .astype(int)
        .tolist()
    )

    verification = {
        "seed": int(seed),
        "source_zip": str(zip_path),
        "feature_shape_saved": meta["feature_shape"],
        "feature_shape_loaded": list(
            feature_tensor.shape
        ),
        "feature_mode": cfg["feature_mode"],
        "energy_weight": energy_weight,
        "min_cluster_size": int(
            cfg["min_cluster_size"]
        ),
        "min_samples": int(
            cfg["min_samples"]
        ),
        "metric": str(cfg["metric"]),
        "saved_backend": logs[0]["backend"],
        "cluster_checks": checks,
        "all_cluster_sizes_match": all(
            x["size_match"]
            for x in checks
        ),
        "max_abs_diff_cluster_mean_z": max(
            x["abs_diff_mean_energy_z"]
            for x in checks
        ),
        "final_candidates_saved": final_candidates,
        "client_ids_with_label_not_0": label_not_main_ids,
        "label_not_0_equals_saved_final_candidates": (
            label_not_main_ids
            == final_candidates
        ),
        "important_note": (
            "HDBSCAN label 是聚类标签。-1 为 Noise；"
            "Cluster 1/2/Noise 不解释为 DBA 四个分片的一一对应。"
        ),
    }

    (out / "verification.json").write_text(
        json.dumps(
            verification,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    if not verification["all_cluster_sizes_match"]:
        raise RuntimeError(
            f"Seed{seed}: 重新聚类的 cluster size 与正式日志不一致。"
        )

    if verification["max_abs_diff_cluster_mean_z"] > 1e-10:
        raise RuntimeError(
            f"Seed{seed}: z_i 与正式日志的簇均值不一致。"
        )

    if not verification["label_not_0_equals_saved_final_candidates"]:
        raise RuntimeError(
            f"Seed{seed}: 重新得到的异常成员与保存 final candidates 不一致。"
        )

    return {
        "seed": seed,
        "zip_path": str(zip_path),
        "p_i": p_i,
        "z_i": z_i[:, 0],
        "f_i": f_i,
        "labels": labels,
        "final_candidates": final_candidates,
        "plot_df": plot_df,
        "verification": verification,
    }


def make_z_plot(seed_result: dict, out_root: Path):
    """
    单图，不使用 subplot。
    HDBSCAN label 用不同 marker group 表示；
    Noise 单独用 x；
    final candidates 直接标注 client id。
    """
    seed = seed_result["seed"]
    df = seed_result["plot_df"].copy()
    df = df.sort_values(
        "z_i",
        ascending=False,
    ).reset_index(drop=True)

    fig = plt.figure(figsize=(12, 5.4))
    ax = fig.add_subplot(111)

    x = np.arange(len(df))

    for lab in sorted(
        df["hdbscan_label"].unique().tolist()
    ):
        part = df[
            df["hdbscan_label"] == lab
        ]
        ranks = part.index.to_numpy()
        marker = "x" if lab == -1 else "o"
        label_name = (
            "Noise (-1)"
            if lab == -1
            else f"Cluster {lab}"
        )
        ax.scatter(
            ranks,
            part["z_i"].to_numpy(),
            marker=marker,
            label=label_name,
        )

    selected = df[
        df["is_final_candidate"]
    ]
    for rank, row in selected.iterrows():
        ax.annotate(
            f"C{int(row['client_id'])}",
            (
                rank,
                float(row["z_i"]),
            ),
            xytext=(0, 7),
            textcoords="offset points",
            ha="center",
            fontsize=7,
        )

    ax.axhline(
        0.0,
        linewidth=0.8,
    )
    ax.set_xlabel(
        "Clients sorted by $z_i$ (descending)"
    )
    ax.set_ylabel("$z_i$")
    ax.set_title(
        f"Seed {seed}: real $z_i$, HDBSCAN labels and final candidates"
    )
    ax.legend()
    ax.grid(
        alpha=0.25,
        linestyle="--",
    )

    fig.tight_layout()
    fig.savefig(
        out_root / f"seed_{seed}_z_labels_candidates.png",
        dpi=300,
        bbox_inches="tight",
    )
    fig.savefig(
        out_root / f"seed_{seed}_z_labels_candidates.pdf",
        bbox_inches="tight",
    )
    plt.close(fig)


def fit_shared_display_pca(seed_results: list[dict]):
    """
    固定显示规则：
    1. 拼接三个 Seed 的真实 37D f_i，共 300×37；
    2. 仅做 PCA 自带的均值中心化；
    3. PCA(n_components=2, svd_solver='full')；
    4. 同一个 PCA basis 显示全部三个 Seed。

    此 PCA 绝不参与 HDBSCAN，只供论文可视化。
    """
    X = np.concatenate(
        [
            x["f_i"]
            for x in seed_results
        ],
        axis=0,
    )
    pca = PCA(
        n_components=2,
        svd_solver="full",
    )
    pca.fit(X)
    return pca


def make_pca_plot(
    seed_result: dict,
    pca: PCA,
    out_root: Path,
):
    seed = seed_result["seed"]
    f_i = seed_result["f_i"]
    labels = seed_result["labels"]
    candidate_set = set(
        seed_result["final_candidates"]
    )

    xy = pca.transform(f_i)

    fig = plt.figure(figsize=(7.2, 6.2))
    ax = fig.add_subplot(111)

    for lab in sorted(np.unique(labels).tolist()):
        idx = np.where(labels == lab)[0]
        marker = "x" if lab == -1 else "o"
        label_name = (
            "Noise (-1)"
            if lab == -1
            else f"Cluster {lab}"
        )
        ax.scatter(
            xy[idx, 0],
            xy[idx, 1],
            marker=marker,
            label=label_name,
        )

    # final candidates 仅用 Client ID 文字做真实标记，不人为修改簇标签。
    for cid in sorted(candidate_set):
        ax.annotate(
            f"C{cid}",
            (
                xy[cid, 0],
                xy[cid, 1],
            ),
            xytext=(4, 4),
            textcoords="offset points",
            fontsize=7,
        )

    ax.set_xlabel("Display PC1")
    ax.set_ylabel("Display PC2")
    ax.set_title(
        f"Seed {seed}: 37-D $f_i$ shared PCA projection\n"
        "(display only; NOT used by HDBSCAN)"
    )
    ax.legend()
    ax.grid(
        alpha=0.25,
        linestyle="--",
    )

    fig.tight_layout()
    fig.savefig(
        out_root / f"seed_{seed}_f_i_pca_display_only.png",
        dpi=300,
        bbox_inches="tight",
    )
    fig.savefig(
        out_root / f"seed_{seed}_f_i_pca_display_only.pdf",
        bbox_inches="tight",
    )
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input-root",
        type=str,
        default="/kaggle/input",
    )
    parser.add_argument(
        "--output-root",
        type=str,
        default="/kaggle/working/HF_WSTGuard_3Seed_HDBSCAN_REAL_DATA",
    )
    args = parser.parse_args()

    input_root = Path(args.input_root)
    output_root = Path(args.output_root)
    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    seed_results = []
    for seed in SEEDS:
        zip_path = find_seed_zip(
            input_root,
            seed,
        )
        print(
            f"[Seed {seed}] source ZIP = {zip_path}"
        )
        result = reconstruct_seed(
            seed,
            zip_path,
            output_root,
        )
        seed_results.append(result)

    # 合并逐客户端数据
    frames = []
    for result in seed_results:
        df = result["plot_df"].copy()
        df.insert(
            0,
            "seed",
            result["seed"],
        )
        frames.append(df)

    pd.concat(
        frames,
        ignore_index=True,
    ).to_csv(
        output_root / "all_seeds_hdbscan_plot_data.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # z_i + label + final candidate 单图
    for result in seed_results:
        make_z_plot(
            result,
            output_root,
        )

    # 37D f_i：三个 Seed 共用一个固定 PCA basis，只供显示
    pca = fit_shared_display_pca(
        seed_results
    )

    pca_meta = {
        "rule": (
            "Concatenate the real 37-D f_i from Seeds 44/55/66; "
            "fit PCA(n_components=2, svd_solver='full') with PCA's "
            "standard mean-centering; use the same PCA basis for all seeds."
        ),
        "display_only": True,
        "used_by_hdbscan": False,
        "explained_variance_ratio": (
            pca.explained_variance_ratio_
            .astype(float)
            .tolist()
        ),
    }
    (
        output_root
        / "display_pca_metadata.json"
    ).write_text(
        json.dumps(
            pca_meta,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    for result in seed_results:
        make_pca_plot(
            result,
            pca,
            output_root,
        )

    archive = shutil.make_archive(
        "/kaggle/working/HF_WSTGuard_3Seed_HDBSCAN_REAL_DATA",
        "zip",
        root_dir=output_root,
    )

    print("\n" + "=" * 90)
    print("EXPORT AND VERIFICATION COMPLETE")
    print("=" * 90)
    for result in seed_results:
        v = result["verification"]
        print(
            f"Seed {result['seed']} | "
            f"cluster_size_match={v['all_cluster_sizes_match']} | "
            f"max_mean_z_diff={v['max_abs_diff_cluster_mean_z']:.3e} | "
            f"candidate_match={v['label_not_0_equals_saved_final_candidates']}"
        )
    print("ARCHIVE =", archive)


if __name__ == "__main__":
    main()
