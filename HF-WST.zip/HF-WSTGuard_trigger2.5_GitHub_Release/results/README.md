# Results are intentionally not tracked

This repository contains experiment code only. Model checkpoints, Kaggle outputs, logs, and result ZIPs are excluded from Git.

Locked CIFAR-10 / ResNet18 / trigger=2.5 paper targets (Seeds 44/55/66):

| Method | Clean Accuracy | ASR |
|---|---:|---:|
| FedAvg-Clean | 85.05 ± 1.88% | 1.98 ± 1.42% |
| FedAvg-Attack | 85.78 ± 1.91% | 100.00 ± 0.00% |
| HF-WSTGuard + RiskFedAvg | 85.49 ± 0.62% | 4.02 ± 0.64% |
| Oracle | 85.32 ± 1.27% | 1.48 ± 1.12% |

Pooled detection: TP=30, FP=0, TN=270, FN=0.
