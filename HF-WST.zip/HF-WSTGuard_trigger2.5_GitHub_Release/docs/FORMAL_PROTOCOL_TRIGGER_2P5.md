# Locked formal protocol — trigger=2.5

- Dataset: CIFAR-10
- Backbone: CIFAR-adapted ResNet18 (3x3 conv1, stride=1, maxpool=Identity)
- Seeds: 44, 55, 66
- Clients: 100
- Dirichlet alpha: 0.3
- Malicious ratio: 0.10
- Poison rate: 0.15
- DBA partitions: 4
- Target label: 0
- Trigger size: 3
- Trigger value: 2.5 (normalized tensor space)
- Total rounds: 300
- Shared attack warmup: R1–R20
- Continuation: R21–R300
- Clients/round: 20
- Local epochs: 2
- Optimizer: Adam, lr=0.003
- Batch size: 64
- WST: J=2, L=6
- Retained high-frequency channels: 13–48 (36 channels, zero-based)
- TopK ratio: 0.10
- Spatial pooling: MaxPool
- Feature mode: direction_energy
- Energy weight: 1.5
- HDBSCAN: min_cluster_size=3, min_samples=1, metric=euclidean, EOM
- max_candidate_ratio=0.20
- min_energy_z=0.80
- outlier_quantile=0.85
- Risk ceiling=0.95

## Important
This folder is the locked trigger=2.5 formal experiment release. The later legal-range trigger=1.0 validation study is intentionally excluded.
