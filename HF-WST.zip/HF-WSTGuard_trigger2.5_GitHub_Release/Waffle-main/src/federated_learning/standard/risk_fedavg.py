"""
Risk-aware FedAvg

HF-WSTGuard Stage-2 aggregation.

Idea:

Detection module produces:

    risk_scores[i] in [0,1]


Higher risk:

    lower aggregation weight


Weight:

    w_i = (1-risk_i)
           ----------------
           sum(1-risk_j)


Then:

    W_global =
        sum w_i W_i

"""


from typing import Dict, List

import torch



class RiskFedAvg:


    def __init__(
        self,
        eps: float = 1e-12,
    ):

        self.eps = eps



    def compute_weights(
        self,
        client_ids: List[int],
        risk_scores: torch.Tensor,
    ):

        """
        Compute client aggregation weights.
        """


        selected_risk = (
            risk_scores[
                torch.tensor(
                    client_ids,
                    dtype=torch.long,
                    device=risk_scores.device
                )
            ]
        )


        weights = (
            1.0 -
            selected_risk
        )


        weights = torch.clamp(
            weights,
            min=0.0
        )


        total = (
            weights.sum()
            +
            self.eps
        )


        weights = (
            weights /
            total
        )


        return weights



    def aggregate(
        self,
        client_states:
            List[Dict[str, torch.Tensor]],

        client_ids:

            List[int],

        risk_scores:

            torch.Tensor,

    ):

        """
        Risk-aware FedAvg aggregation.

        Args:

            client_states:

                List of local model state_dict


            client_ids:

                global client ids


            risk_scores:

                [num_clients]


        Return:

            aggregated state_dict
        """


        if len(client_states) == 0:

            raise ValueError(
                "No client updates."
            )


        weights = self.compute_weights(
            client_ids,
            risk_scores,
        )


        new_state = {}


        keys = (
            client_states[0]
            .keys()
        )


        for key in keys:


            new_state[key] = sum(

                weights[i]
                *
                client_states[i][key]

                for i in range(
                    len(client_states)
                )

            )



        return new_state



def risk_fedavg(
    client_states,
    client_ids,
    risk_scores,
):

    """
    Functional interface.
    """

    aggregator = RiskFedAvg()

    return aggregator.aggregate(
        client_states,
        client_ids,
        risk_scores,
    )