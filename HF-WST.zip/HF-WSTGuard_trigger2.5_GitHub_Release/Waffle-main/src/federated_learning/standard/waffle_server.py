import torch
import copy
from src.federated_learning.standard.fedavg import Server as FedAvgServer


class WaffleServer(FedAvgServer):
    """
    创新点三：WST 引导的解耦距离感知聚合服务器
    """

    def __init__(self, clients, participation_rate, model, R_matrix=None, gamma=0.5):
        super().__init__(clients, participation_rate, model)
        # 传入之前探测器算出来的置信度矩阵
        self.R_matrix = R_matrix
        # 距离衰减系数
        self.gamma = gamma

    def aggregate(self, clients_idx):
        """
        重写聚合函数，执行解耦聚合！
        clients_idx: 当前被选中参与本轮聚合的客户端 ID 列表
        """
        num_participants = len(clients_idx)
        if num_participants == 0:
            return

        new_global_state = copy.deepcopy(self.model.state_dict())

        # 1. 拆解网络结构：识别哪些是分类器参数，哪些是特征提取器参数
        # (假设你的网络最后一层叫 'fc' 或 'classifier' 或 'linear')
        classifier_keys = [k for k in new_global_state.keys() if 'fc' in k or 'classifier' in k or 'linear' in k]
        feature_extractor_keys = [k for k in new_global_state.keys() if k not in classifier_keys]

        # 提取当前轮次参与者的模型
        participating_models = [self.clients[idx].model.state_dict() for idx in clients_idx]
        global_state = self.model.state_dict()

        # ==========================================
        # 步骤 A：特征提取层的【距离感知聚合】 (隔离底层毒素)
        # ==========================================
        feature_weights = []
        for i, c_state in enumerate(participating_models):
            # 展平客户端和全局的特征层参数
            c_feat = torch.cat([c_state[name].flatten() for name in feature_extractor_keys])
            g_feat = torch.cat([global_state[name].flatten() for name in feature_extractor_keys])

            # 计算欧氏距离并得出衰减权重
            distance = torch.norm(c_feat - g_feat, p=2)
            weight = torch.exp(-self.gamma * distance)
            feature_weights.append(weight)

        feature_weights = torch.tensor(feature_weights)
        feature_weights = feature_weights / feature_weights.sum()  # 归一化

        # 聚合特征提取层
        for name in feature_extractor_keys:
            new_global_state[name] = sum(feature_weights[i] * participating_models[i][name]
                                         for i in range(num_participants))

        # ==========================================
        # 步骤 B：分类器层的【类级别置信度聚合】 (精准剔除)
        # ==========================================
        # 如果没有传入 R_matrix，退化为普通平均
        if self.R_matrix is None:
            for name in classifier_keys:
                new_global_state[name] = sum(
                    participating_models[i][name] for i in range(num_participants)) / num_participants
        else:
            num_classes = self.R_matrix.shape[1]
            for name in classifier_keys:
                aggregated_weight = torch.zeros_like(new_global_state[name])

                # 特殊处理 bias (偏置是一维的，权重是二维的)
                is_bias = len(new_global_state[name].shape) == 1

                for c in range(num_classes):
                    # 取出这批参与者在类别 c 上的置信度
                    # 注意：clients_idx 是全局 ID 列表
                    confidences = torch.tensor([self.R_matrix[idx, c] for idx in clients_idx])

                    if confidences.sum() == 0:
                        norm_conf = torch.ones(num_participants) / num_participants
                    else:
                        norm_conf = confidences / confidences.sum()

                    for i in range(num_participants):
                        if is_bias:
                            aggregated_weight[c] += norm_conf[i] * participating_models[i][name][c]
                        else:
                            # 权重参数形如 [out_features, in_features]，c 对应的是 out_features 维度
                            aggregated_weight[c, :] += norm_conf[i] * participating_models[i][name][c, :]

                new_global_state[name] = aggregated_weight

        # 将手术后的参数加载回全局模型
        self.model.load_state_dict(new_global_state)