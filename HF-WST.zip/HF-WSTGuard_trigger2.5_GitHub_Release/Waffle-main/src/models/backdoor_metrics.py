from __future__ import annotations

from typing import Optional, Any

import torch
from torch.utils.data import DataLoader


def _get_client_test_loader(client: Any, batch_size: int = 128):
    """
    尽量兼容你当前项目里的 Client 写法。
    优先使用已有 test dataloader；如果没有，则从 _test_dataset 构造。
    """
    if hasattr(client, "_test_dataloader") and client._test_dataloader is not None:
        return client._test_dataloader

    if hasattr(client, "test_dataloader") and client.test_dataloader is not None:
        return client.test_dataloader

    if hasattr(client, "_test_dataset"):
        return DataLoader(
            client._test_dataset,
            batch_size=batch_size,
            shuffle=False,
        )

    if hasattr(client, "test_dataset"):
        return DataLoader(
            client.test_dataset,
            batch_size=batch_size,
            shuffle=False,
        )

    raise AttributeError("无法从 client 中找到 test dataloader 或 test dataset。")


def _apply_attack_batch(X: torch.Tensor, attack: Any, device: str) -> torch.Tensor:
    """
    对一个 batch 的图片加 trigger。

    如果 attack 支持 batch 输入，直接 attack(X)；
    如果不支持，则逐张图片加 trigger。
    """
    try:
        X_poisoned = attack(X)
        return X_poisoned.to(device)
    except Exception:
        poisoned_imgs = []
        for x in X:
            poisoned_imgs.append(attack(x.detach().cpu()).to(device))
        return torch.stack(poisoned_imgs, dim=0)


@torch.no_grad()
def evaluate_asr_on_clients(
    model: torch.nn.Module,
    eval_clients: list[Any],
    attack: Any,
    target_label: int = 0,
    device: str = "cpu",
    batch_size: int = 128,
    max_batches_per_client: Optional[int] = None,
) -> dict[str, float]:
    """
    计算 Attack Success Rate, ASR。

    ASR 定义：
    对 clean test set 中所有非 target label 样本加 trigger；
    如果模型预测为 target_label，则认为攻击成功。

    注意：
    - target label 原本就是目标类的样本不参与 ASR 统计；
    - eval_clients 建议使用 clean clients 或 clean test clients；
    - attack 应该是 BadNets / DBA 等图像触发器攻击对象。
    """
    model.eval()
    model.to(device)

    total = 0
    success = 0

    for client in eval_clients:
        loader = _get_client_test_loader(client, batch_size=batch_size)

        batch_count = 0

        for X, y in loader:
            X = X.to(device)
            y = y.to(device)

            # ASR 只统计原始标签不是 target_label 的样本
            mask = y != target_label
            if mask.sum().item() == 0:
                continue

            X_non_target = X[mask]
            y_non_target = y[mask]

            X_poisoned = _apply_attack_batch(
                X_non_target,
                attack=attack,
                device=device,
            )

            logits = model(X_poisoned)
            pred = logits.argmax(dim=1)

            success += (pred == target_label).sum().item()
            total += y_non_target.numel()

            batch_count += 1
            if max_batches_per_client is not None and batch_count >= max_batches_per_client:
                break

    asr = success / max(total, 1)

    return {
        "asr": float(asr),
        "success": int(success),
        "total": int(total),
    }


@torch.no_grad()
def evaluate_clean_accuracy_on_clients(
    model: torch.nn.Module,
    eval_clients: list[Any],
    device: str = "cpu",
    batch_size: int = 128,
    max_batches_per_client: Optional[int] = None,
) -> dict[str, float]:
    """
    直接计算 clean test accuracy。
    你也可以继续使用 server.evaluate()，这个函数主要用于和 ASR 放在一起统一输出。
    """
    model.eval()
    model.to(device)

    correct = 0
    total = 0

    for client in eval_clients:
        loader = _get_client_test_loader(client, batch_size=batch_size)

        batch_count = 0

        for X, y in loader:
            X = X.to(device)
            y = y.to(device)

            logits = model(X)
            pred = logits.argmax(dim=1)

            correct += (pred == y).sum().item()
            total += y.numel()

            batch_count += 1
            if max_batches_per_client is not None and batch_count >= max_batches_per_client:
                break

    acc = correct / max(total, 1)

    return {
        "clean_acc": float(acc),
        "correct": int(correct),
        "total": int(total),
    }