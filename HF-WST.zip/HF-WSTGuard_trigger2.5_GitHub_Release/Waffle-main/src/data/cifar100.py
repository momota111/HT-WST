from os.path import join
from PIL import Image
from torch import Tensor
from torchvision.transforms import Compose, ToTensor, Normalize, RandomAffine
from typing import Optional, Dict, List, Any

from src.data.base import BaseDataset, FederationSampler
from src.data.attacks import Attack

TRAIN_DATA_PATH = join("data", "cifar100", "train")
TEST_DATA_PATH = join("data", "cifar100", "test")


class Dataset(BaseDataset):

    def __init__(
            self,
            data: Dict[str, List[Any]],
            train: bool,
            attack: Optional[Attack] = None
    ):
        super(Dataset, self).__init__(data)
        self.attack = attack
        # 💡 修改 1：去除 loading_transforms 中的 attack，保持加载时的纯净
        loading_transforms = [ToTensor(), Normalize((.5, .5, .5), (.5, .5, .5))]
        self.loading_transforms = Compose(loading_transforms)

        self.training_transforms = RandomAffine(degrees=90, translate=(.1, .1), scale=(.9, 1.1)) if train else None
        return

    def __getitem__(self, index: int) -> list[Tensor, int]:
        X, y = self.cache[index]

        # 💡 修改 2：先进行仿射变换 (数据增强)
        if self.training_transforms is not None:
            X = self.training_transforms(X)

        # 💡 修改 3：在数据增强之后，再盖上后门戳，确保触发器死死钉在指定位置
        if self.attack is not None:
            X = self.attack(X)

        return X, y

    def load(self):
        for img_path, y in zip(self.X, self.y):
            # 💡 修改 4：从源头强行替换被污染客户端的标签
            if self.attack is not None and self.attack.id == "badnets":
                final_y = self.attack.target_label
            else:
                final_y = y

            x = Image.open(img_path).convert("RGB")
            x = self.loading_transforms(x)

            # 将篡改后的标签存入内存
            self.cache.append((x, final_y))

        # 💡 同步更新类的标签列表，保证按类别提取特征的防御引擎能精准定位
        self.y = [self.cache[i][1] for i in range(len(self.cache))]
        return


def get_federation(num_shards: int, alpha: float, attacks: list[Attack] = [], attacks_proba: float = 0.) -> list[
    Dict[str, Dataset]]:
    # CIFAR-100 的 sampler 类别数是 100，这里保持不变
    sampler = FederationSampler(TRAIN_DATA_PATH, TEST_DATA_PATH, "png", 100)
    federation = sampler.sample_federation(Dataset, num_shards, alpha, attacks, attacks_proba)
    return federation