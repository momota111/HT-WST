from torch import Tensor, rand, rand_like, zeros_like, normal, no_grad
from torchvision.transforms.functional import gaussian_blur
import torch
import random


class Attack(object):

    def __init__(
            self
    ):
        self.id = None
        return

    def __call__(
            self,
            X: Tensor
    ) -> Tensor:
        return self.forward(X)

    def __str__(
            self
    ):
        return self.id

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        return


class GaussianNoise(Attack):

    def __init__(
            self,
            sigma: float
    ):
        super(GaussianNoise, self).__init__()
        self.sigma = sigma
        self.id = "gaussian_noise"
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        noise = normal(mean=0., std=self.sigma, size=X.size(), requires_grad=False)
        return X + noise


class GaussianBlur(Attack):

    def __init__(
            self,
            kernel_size: int
    ):
        super(GaussianBlur, self).__init__()
        self.kernel_size = kernel_size
        self.id = "gaussian_blur"
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        return gaussian_blur(X, self.kernel_size)


class Negative(Attack):

    def __init__(
            self
    ):
        super(Negative, self).__init__()
        self.id = "negative"
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        return -X


class Black(Attack):

    def __init__(
            self
    ):
        super(Black, self).__init__()
        self.id = "black"
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        return zeros_like(X, requires_grad=False)


class RandomCancellation(Attack):

    def __init__(
            self,
            proba: float = 0.5
    ):
        super(RandomCancellation, self).__init__()
        self.id = "random_cancellation"
        self.p = proba
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        rand_mask = rand_like(X) > self.p
        X_new = X.clone()
        X_new[rand_mask] = 0.
        return X_new


class ShiftEmbedding(Attack):

    def __init__(
            self,
            proba: float = 0.5
    ):
        super(ShiftEmbedding, self).__init__()
        self.id = "shift_embedding"
        self.p = proba
        return

    @no_grad()
    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        shift = rand_like(X)
        shift = X[X != 0.].norm(keepdim=True) * shift / shift.norm(keepdim=True)
        mask = rand(X.size(1), device=X.device).type(X.dtype) <= self.p
        shift[:, mask] = 0.
        return X + shift


class LabelFlipping(Attack):
    """
    创新点二新增：标签翻转攻击 (Label-Flipping)
    将恶意客户端的本地标签进行系统性偏移，例如猫(3)变成狗(4)
    """

    def __init__(
            self,
            target_shift: int = 1,
            num_classes: int = 10
    ):
        super(LabelFlipping, self).__init__()
        self.id = "label_flipping"
        self.target_shift = target_shift
        self.num_classes = num_classes
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        # 标签翻转不改变底层图像像素分布，直接返回原图
        return X


class BadNets(Attack):
    """
    纯净版 BadNets 后门攻击 (仅注入视觉触发器)
    """

    def __init__(
            self,
            target_label: int = 0  # 💡 新增：后门攻击的目标类别（比如让所有带触发器的图片都识别为 0 也就是飞机）
    ):
        super(BadNets, self).__init__()
        # 💡 核心修改：将 id 正式命名为 "badnets"！
        # 这样底层的代码就不会再执行 label_flipping 的全局翻转逻辑了
        self.id = "badnets"
        self.target_label = target_label
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        # 1. 克隆原图，防止直接修改底层内存
        X_poisoned = X.clone()

        # 2. 注入后门触发器 (Trigger)
        # 在图像的右下角打上一个 4x4 的高亮像素块
        X_poisoned[..., -4:, -4:] = 2.5

        return X_poisoned


class DynamicBadNets(Attack):
    """
    方案一：动态漂移后门 (Dynamic/Moving Trigger)
    触发器大小固定 (如 4x4)，但在图像上的位置完全随机。
    """

    def __init__(
            self,
            target_label: int = 0,
            trigger_size: int = 4
    ):
        super(DynamicBadNets, self).__init__()
        # 💡 核心伪装：向外部宣称自己还是普通的 badnets，
        # 这样 dataset 里的标签劫持逻辑 (if self.attack.id == "badnets") 就会继续生效！
        self.id = "badnets"
        self.target_label = target_label
        self.trigger_size = trigger_size
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        # 1. 克隆原图，防止直接修改底层内存
        X_poisoned = X.clone()

        # 2. 获取图像的高度和宽度 (通常为 32x32)
        h, w = X.shape[-2], X.shape[-1]

        # 3. 计算触发器左上角的合法随机范围 (防止越界)
        max_y = h - self.trigger_size
        max_x = w - self.trigger_size

        # 4. 生成随机坐标
        start_y = random.randint(0, max_y)
        start_x = random.randint(0, max_x)

        # 5. 在随机位置注入高亮后门触发器
        X_poisoned[..., start_y: start_y + self.trigger_size,
        start_x: start_x + self.trigger_size] = 2.5

        return X_poisoned


class MultiTargetBadNets(Attack):
    """
    多重后门攻击 (Multi-target Backdoors)
    支持将不同的触发器样式映射到不同的目标类别上。
    """

    def __init__(
            self,
            target_label: int,
            trigger_style: str = "bottom_right"
    ):
        super(MultiTargetBadNets, self).__init__()
        # 💡 继续伪装成 badnets，享受 cifar10.py 提供的免费标签篡改服务！
        self.id = "badnets"
        self.target_label = target_label
        self.trigger_style = trigger_style
        self.trigger_size = 4
        return

    def forward(
            self,
            X: Tensor
    ) -> Tensor:
        X_poisoned = X.clone()
        h, w = X.shape[-2], X.shape[-1]
        s = self.trigger_size

        # 根据不同的 trigger_style，在图像的不同物理位置注入高频能量
        if self.trigger_style == "bottom_right":
            X_poisoned[..., -s:, -s:] = 2.5
        elif self.trigger_style == "top_left":
            X_poisoned[..., :s, :s] = 2.5
        elif self.trigger_style == "top_right":
            X_poisoned[..., :s, -s:] = 2.5
        elif self.trigger_style == "bottom_left":
            X_poisoned[..., -s:, :s] = 2.5
        elif self.trigger_style == "center":
            cy, cx = h // 2, w // 2
            X_poisoned[..., cy - s // 2: cy + s // 2, cx - s // 2: cx + s // 2] = 2.5

        return X_poisoned



class DistributedBadNets(Attack):
    """
    DBA: Distributed Backdoor Attack.

    用法：
    1) 训练阶段：不同恶意客户端只注入一个局部 sub-trigger。
       partition_id = 0/1/2/3 分别代表左上、右上、左下、右下。
    2) ASR 测试阶段：使用 global_trigger=True，把四个 sub-trigger 同时注入到测试样本中。

    注意：
    - id 不再伪装成 badnets，而是 dba_p0/dba_p1/...，便于实验记录。
    - CIFAR10 Dataset 已经通过 target_label 或 transform_label() 改标签，所以不需要 id == "badnets"。
    """

    def __init__(
            self,
            target_label: int = 0,
            partition_id: int = 0,
            trigger_size: int = 2,
            trigger_value: float = 2.5,
            num_partitions: int = 4,
            global_trigger: bool = False,
    ):
        super(DistributedBadNets, self).__init__()
        self.target_label = int(target_label)
        self.partition_id = int(partition_id)
        self.trigger_size = int(trigger_size)
        self.trigger_value = float(trigger_value)
        self.num_partitions = int(num_partitions)
        self.global_trigger = bool(global_trigger)

        if self.global_trigger:
            self.id = "dba_global"
        else:
            self.id = f"dba_p{self.partition_id}"

    def transform_label(self, y: int) -> int:
        """所有 poisoned samples 都映射到目标类别。"""
        return self.target_label

    def _fragment_slices(self, h: int, w: int, partition_id: int):
        """返回某个 sub-trigger 在图像中的空间位置。"""
        s = self.trigger_size

        if partition_id % 4 == 0:
            return slice(0, s), slice(0, s)              # 左上
        if partition_id % 4 == 1:
            return slice(0, s), slice(w - s, w)          # 右上
        if partition_id % 4 == 2:
            return slice(h - s, h), slice(0, s)          # 左下
        if partition_id % 4 == 3:
            return slice(h - s, h), slice(w - s, w)      # 右下

        raise ValueError(f"Unsupported partition_id={partition_id}")

    def _apply_one_fragment(self, X: Tensor, partition_id: int) -> Tensor:
        h, w = X.shape[-2], X.shape[-1]
        ys, xs = self._fragment_slices(h, w, partition_id)
        X[..., ys, xs] = self.trigger_value
        return X

    def forward(self, X: Tensor) -> Tensor:
        X_poisoned = X.clone()

        if self.global_trigger:
            for pid in range(self.num_partitions):
                X_poisoned = self._apply_one_fragment(X_poisoned, pid)
        else:
            X_poisoned = self._apply_one_fragment(X_poisoned, self.partition_id)

        return X_poisoned


def make_dba_attacks(
        target_label: int = 0,
        trigger_size: int = 2,
        trigger_value: float = 2.5,
        num_partitions: int = 4,
):
    """
    生成 DBA 训练阶段使用的局部 sub-trigger 攻击列表。
    配合 get_federation(..., attack_assignment="round_robin") 使用，
    可以让恶意客户端按 p0,p1,p2,p3,p0,... 分配触发器碎片。
    """
    return [
        DistributedBadNets(
            target_label=target_label,
            partition_id=pid,
            trigger_size=trigger_size,
            trigger_value=trigger_value,
            num_partitions=num_partitions,
            global_trigger=False,
        )
        for pid in range(num_partitions)
    ]


def make_dba_global_attack(
        target_label: int = 0,
        trigger_size: int = 2,
        trigger_value: float = 2.5,
        num_partitions: int = 4,
):
    """
    生成 DBA 测试阶段 ASR 使用的完整全局触发器。
    训练时每个恶意客户端只拿一个 fragment，测试时把所有 fragments 合起来。
    """
    return DistributedBadNets(
        target_label=target_label,
        partition_id=0,
        trigger_size=trigger_size,
        trigger_value=trigger_value,
        num_partitions=num_partitions,
        global_trigger=True,
    )
class BlendedAttack(Attack):
    """
    Blended Backdoor Attack for normalized CIFAR-10 tensors.

    你的 CIFAR-10 pipeline 使用：
        ToTensor() + Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))

    所以图像张量 X 的范围大约是 [-1, 1]。
    因此这里的 trigger pattern 也在 [-1, 1] 归一化空间里构造。

    投毒公式：
        X_poisoned = (1 - alpha) * X + alpha * trigger_pattern
    """

    def __init__(
            self,
            target_label: int = 0,
            alpha: float = 0.20,
            pattern_type: str = "checkerboard",
            seed: int = 1234,
            clamp: bool = True,
    ):
        super(BlendedAttack, self).__init__()
        self.id = f"blended_{pattern_type}_a{alpha:.2f}"
        self.target_label = int(target_label)
        self.alpha = float(alpha)
        self.pattern_type = str(pattern_type)
        self.seed = int(seed)
        self.clamp = bool(clamp)

    def transform_label(self, y: int) -> int:
        """所有 poisoned samples 都映射到目标类别。"""
        return self.target_label

    def _make_pattern(self, X: Tensor) -> Tensor:
        """生成和 X 形状、设备、类型一致的 trigger pattern。"""
        if X.dim() == 3:
            c, h, w = X.shape
            batch_shape = None
        elif X.dim() == 4:
            b, c, h, w = X.shape
            batch_shape = (b,)
        else:
            raise ValueError(
                f"BlendedAttack expects X with shape (C,H,W) or (B,C,H,W), got {tuple(X.shape)}"
            )

        device = X.device
        dtype = X.dtype

        if self.pattern_type == "checkerboard":
            yy = torch.arange(h, device=device).view(h, 1)
            xx = torch.arange(w, device=device).view(1, w)
            pattern_2d = ((yy + xx) % 2).to(dtype) * 2.0 - 1.0
            pattern = pattern_2d.view(1, h, w).repeat(c, 1, 1)

        elif self.pattern_type == "stripe":
            xx = torch.arange(w, device=device).view(1, w)
            pattern_2d = ((xx // 2) % 2).to(dtype) * 2.0 - 1.0
            pattern = pattern_2d.view(1, h, w).repeat(c, h, 1)

        elif self.pattern_type == "constant":
            pattern = torch.ones((c, h, w), device=device, dtype=dtype)

        elif self.pattern_type == "noise":
            gen = torch.Generator(device="cpu")
            gen.manual_seed(self.seed)
            pattern = torch.rand((c, h, w), generator=gen, dtype=dtype) * 2.0 - 1.0
            pattern = pattern.to(device)

        else:
            raise ValueError(
                f"Unknown pattern_type={self.pattern_type}. "
                f"Use 'checkerboard', 'stripe', 'constant', or 'noise'."
            )

        if batch_shape is not None:
            pattern = pattern.unsqueeze(0).repeat(batch_shape[0], 1, 1, 1)

        return pattern

    def forward(self, X: Tensor) -> Tensor:
        X_poisoned = X.clone()
        pattern = self._make_pattern(X_poisoned)

        X_poisoned = (1.0 - self.alpha) * X_poisoned + self.alpha * pattern

        if self.clamp:
            X_poisoned = X_poisoned.clamp(-1.0, 1.0)

        return X_poisoned


def make_blended_attack(
        target_label: int = 0,
        alpha: float = 0.20,
        pattern_type: str = "checkerboard",
        seed: int = 1234,
):
    """
    生成 Blended Attack。
    使用方式：
        blended_attack = make_blended_attack(
            target_label=0,
            alpha=0.20,
            pattern_type="checkerboard",
        )
    """
    return BlendedAttack(
        target_label=target_label,
        alpha=alpha,
        pattern_type=pattern_type,
        seed=seed,
        clamp=True,
    )