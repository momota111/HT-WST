from __future__ import annotations

from functools import partial
from os.path import join
from typing import Any, Dict, List, Optional

import numpy as np
from PIL import Image
from torch import Tensor
from torchvision.transforms import Compose, Normalize, RandomCrop, RandomHorizontalFlip, ToTensor

from src.data.attacks import Attack
from src.data.base import BaseDataset, FederationSampler

TRAIN_DATA_PATH = join("data", "cifar10", "train")
TEST_DATA_PATH = join("data", "cifar10", "test")


class Dataset(BaseDataset):
    """
    CIFAR-10 client dataset with standard partial-poison backdoor protocol.

    改动重点：
    1. 不再整客户端全量投毒；
    2. 使用 poison_rate 控制投毒比例；
    3. 只有 poisoned samples 才改标签；
    4. 保留 original_y 仅用于仿真数据管理和离线诊断；正式检测不依赖它；
    5. 检测时使用 get_detection_image() 读取实际输入图像，再由全局模型生成伪标签；
    6. CIFAR-10 增强改成 RandomCrop + HorizontalFlip，不再使用 90 度 RandomAffine。
    """

    _auto_client_counter = 0

    def __init__(
        self,
        data: Dict[str, List[Any]],
        train: bool,
        attack: Optional[Attack] = None,
        poison_rate: float = 0.20,
        seed: int = 42,
        client_id: Optional[int] = None,
        use_standard_aug: bool = True,
    ):
        super(Dataset, self).__init__(data)

        if client_id is None:
            client_id = Dataset._auto_client_counter
            Dataset._auto_client_counter += 1

        self.attack = attack
        self.train = bool(train)
        self.poison_rate = float(poison_rate)
        self.seed = int(seed)
        self.client_id = int(client_id)
        self.use_standard_aug = bool(use_standard_aug)

        self.original_y = [int(v) for v in self.y]

        self.loading_transforms = Compose([
            ToTensor(),
            Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
        ])

        if self.train and self.use_standard_aug:
            self.training_transforms = Compose([
                RandomCrop(32, padding=4),
                RandomHorizontalFlip(),
            ])
        else:
            self.training_transforms = None

        self.poison_indices = self._build_poison_indices()

    def _build_poison_indices(self) -> set[int]:
        if self.attack is None or self.poison_rate <= 0.0 or self.num_samples == 0:
            return set()

        poison_num = int(round(self.poison_rate * self.num_samples))
        poison_num = max(1, min(poison_num, self.num_samples))

        split_offset = 0 if self.train else 10_000_000
        rng = np.random.default_rng(self.seed + split_offset + 1009 * self.client_id)
        indices = rng.choice(self.num_samples, size=poison_num, replace=False)
        return set(int(i) for i in indices.tolist())

    def is_poisoned(self, index: int) -> bool:
        return self.attack is not None and int(index) in self.poison_indices

    def _poison_label_if_needed(self, y: int, index: int) -> int:
        """
        只有 poisoned samples 才改标签。

        兼容两种 attack 写法：
        1. attack 有 transform_label()；
        2. attack 只有 target_label。
        """
        if not self.is_poisoned(index):
            return int(y)

        if hasattr(self.attack, "transform_label"):
            try:
                return int(self.attack.transform_label(int(y)))
            except TypeError:
                pass

        if hasattr(self.attack, "target_label") and self.attack.target_label is not None:
            return int(self.attack.target_label)

        return int(y)

    def _maybe_load(self):
        if len(self.cache) == 0:
            self.load()

    def __getitem__(self, index: int) -> tuple[Tensor, int]:
        self._maybe_load()
        X, clean_y = self.cache[index]

        if self.training_transforms is not None:
            X = self.training_transforms(X)

        y = self._poison_label_if_needed(clean_y, index)

        if self.is_poisoned(index):
            X = self.attack(X)

        return X, y

    def get_detection_image(
        self,
        index: int,
        apply_attack: bool = True,
        apply_transform: bool = False,
    ) -> Tensor:
        """
        返回检测模块实际读取到的图像，不返回任何客户端标签。

        正式伪标签协议中：
        - apply_attack=True：若该样本属于本地训练时的投毒样本，则保留触发器；
        - apply_transform=False：关闭随机裁剪与翻转，保证 WST 摘要稳定；
        - 类别由服务器下发的冻结全局模型在可信检测代码中预测。

        注意：该接口消除了检测流程对 original_y / poisoned_y 的直接依赖，
        但不能单独解决恶意客户端替换输入样本或伪造摘要的问题。
        """
        self._maybe_load()
        X, _clean_y = self.cache[index]

        if apply_transform and self.training_transforms is not None:
            X = self.training_transforms(X)

        if apply_attack and self.is_poisoned(index):
            X = self.attack(X)

        return X

    def get_detection_item(
        self,
        index: int,
        use_original_label: bool = True,
        apply_attack: bool = True,
        apply_transform: bool = False,
    ) -> tuple[Tensor, int]:
        """
        兼容旧实验的图像+标签读取接口。

        新的正式伪标签实验不应依赖这里返回的 y，而应调用
        get_detection_image() 后由冻结全局模型预测类别。
        use_original_label=True 仅保留给历史对照和离线诊断。
        """
        self._maybe_load()
        X, clean_y = self.cache[index]

        if apply_transform and self.training_transforms is not None:
            X = self.training_transforms(X)

        if apply_attack and self.is_poisoned(index):
            X = self.attack(X)

        if use_original_label:
            y = int(clean_y)
        else:
            y = self._poison_label_if_needed(clean_y, index)

        return X, y

    def load(self):
        self.cache = []

        for img_path, y in zip(self.X, self.original_y):
            x = Image.open(img_path).convert("RGB")
            x = self.loading_transforms(x)
            self.cache.append((x, int(y)))

        self.y = list(self.original_y)
        return


def get_federation(
    num_shards: int,
    alpha: float,
    attacks: Optional[list[Attack]] = None,
    attacks_proba: float = 0.0,
    poison_rate: float = 0.10,
    seed: int = 42,
    use_standard_aug: bool = True,
    attack_assignment: str = "random",
) -> list[Dict[str, Dataset]]:
    """
    构建标准部分投毒协议下的 CIFAR-10 联邦数据。

    使用示例：
        federation = get_federation(
            num_shards=100,
            alpha=0.5,
            attacks=[BadNets(target_label=0)],
            attacks_proba=0.3,
            poison_rate=0.1,
            seed=42,
        )
    """
    Dataset._auto_client_counter = 0
    attacks = attacks or []

    dataset_class = partial(
        Dataset,
        poison_rate=poison_rate,
        seed=seed,
        use_standard_aug=use_standard_aug,
    )

    sampler = FederationSampler(TRAIN_DATA_PATH, TEST_DATA_PATH, "png", 10)
    federation = sampler.sample_federation(
        dataset_class,
        num_shards,
        alpha,
        attacks,
        attacks_proba,
        attack_assignment=attack_assignment,
    )
    return federation