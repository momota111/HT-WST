from __future__ import annotations

import os
from functools import partial
from os.path import join
from typing import Any, Dict, List, Optional

import numpy as np
from PIL import Image
from torch import Tensor
from torchvision.datasets import FashionMNIST
from torchvision.transforms import Compose, Normalize, RandomCrop, ToTensor

from src.data.attacks import Attack
from src.data.base import BaseDataset, FederationSampler

TRAIN_DATA_PATH = join("data", "fashion_mnist", "train")
TEST_DATA_PATH = join("data", "fashion_mnist", "test")
RAW_DATA_PATH = join("data", "raw_fashion_mnist")


def _folder_has_png(folder: str) -> bool:
    if not os.path.isdir(folder):
        return False
    return any(name.lower().endswith(".png") for name in os.listdir(folder))


def prepare_fashion_mnist_png(force: bool = False) -> None:
    """
    将 torchvision 的 Fashion-MNIST 自动下载并转换成项目 FederationSampler 需要的 png 格式。

    保存格式：
        data/fashion_mnist/train/img_00000_y0.png
        data/fashion_mnist/test/img_00000_y0.png

    你的 FederationSampler 会通过文件名中的 _y{label}.png 解析标签。
    """
    if (not force) and _folder_has_png(TRAIN_DATA_PATH) and _folder_has_png(TEST_DATA_PATH):
        return

    os.makedirs(TRAIN_DATA_PATH, exist_ok=True)
    os.makedirs(TEST_DATA_PATH, exist_ok=True)

    train_set = FashionMNIST(root=RAW_DATA_PATH, train=True, download=True)
    test_set = FashionMNIST(root=RAW_DATA_PATH, train=False, download=True)

    def dump_split(ds: FashionMNIST, out_dir: str) -> None:
        # 如果 force=True，先清理旧 png，避免不同版本文件混杂。
        if force:
            for name in os.listdir(out_dir):
                if name.lower().endswith(".png"):
                    os.remove(join(out_dir, name))

        for idx in range(len(ds)):
            img, label = ds[idx]  # img 是 PIL Image，label 是 int
            img = img.convert("L")
            img.save(join(out_dir, f"img_{idx:05d}_y{int(label)}.png"))

    dump_split(train_set, TRAIN_DATA_PATH)
    dump_split(test_set, TEST_DATA_PATH)


class Dataset(BaseDataset):
    """
    Fashion-MNIST client dataset with standard partial-poison backdoor protocol.

    关键点：
    1. Fashion-MNIST 是灰度图，所以输入 shape 是 [1, 28, 28]；
    2. 只对 poison_indices 中的样本加 trigger 并改标签；
    3. 保存 original_y，WST 检测时可以按原始类别分组，避免 poisoned label 泄漏；
    4. get_detection_item() 默认不使用随机增强，保证频域特征稳定。
    """

    _auto_client_counter = 0

    def __init__(
        self,
        data: Dict[str, List[Any]],
        train: bool,
        attack: Optional[Attack] = None,
        poison_rate: float = 0.10,
        seed: int = 42,
        client_id: Optional[int] = None,
        use_standard_aug: bool = True,
    ):
        super(Dataset, self).__init__(data)

        if client_id is None:
            client_id = Dataset._auto_client_counter
            Dataset._auto_client_counter += 1

        self.attack = attack
        self.train = bool(train)
        self.poison_rate = float(poison_rate)
        self.seed = int(seed)
        self.client_id = int(client_id)
        self.use_standard_aug = bool(use_standard_aug)

        self.original_y = [int(v) for v in self.y]

        self.loading_transforms = Compose([
            ToTensor(),
            Normalize((0.5,), (0.5,)),
        ])

        # Fashion-MNIST 不建议做 90 度旋转，会破坏服装语义。
        # 这里只做轻微 crop padding，和 CIFAR 的增强类似但更保守。
        if self.train and self.use_standard_aug:
            self.training_transforms = Compose([
                RandomCrop(28, padding=2),
            ])
        else:
            self.training_transforms = None

        self.poison_indices = self._build_poison_indices()

    def _build_poison_indices(self) -> set[int]:
        if self.attack is None or self.poison_rate <= 0.0 or self.num_samples == 0:
            return set()

        poison_num = int(round(self.poison_rate * self.num_samples))
        poison_num = max(1, min(poison_num, self.num_samples))

        split_offset = 0 if self.train else 10_000_000
        rng = np.random.default_rng(self.seed + split_offset + 1009 * self.client_id)
        indices = rng.choice(self.num_samples, size=poison_num, replace=False)
        return set(int(i) for i in indices.tolist())

    def is_poisoned(self, index: int) -> bool:
        return self.attack is not None and int(index) in self.poison_indices

    def _poison_label_if_needed(self, y: int, index: int) -> int:
        if not self.is_poisoned(index):
            return int(y)

        if hasattr(self.attack, "transform_label"):
            try:
                return int(self.attack.transform_label(int(y)))
            except TypeError:
                pass

        if hasattr(self.attack, "target_label") and self.attack.target_label is not None:
            return int(self.attack.target_label)

        return int(y)

    def _maybe_load(self) -> None:
        if len(self.cache) == 0:
            self.load()

    def __getitem__(self, index: int) -> tuple[Tensor, int]:
        self._maybe_load()
        X, clean_y = self.cache[index]

        if self.training_transforms is not None:
            X = self.training_transforms(X)

        y = self._poison_label_if_needed(clean_y, index)

        if self.is_poisoned(index):
            X = self.attack(X)

        return X, y

    def get_detection_item(
        self,
        index: int,
        use_original_label: bool = True,
        apply_attack: bool = True,
        apply_transform: bool = False,
    ) -> tuple[Tensor, int]:
        """
        WST 检测专用读取接口。

        推荐：
            use_original_label=True
            apply_attack=True
            apply_transform=False
        """
        self._maybe_load()
        X, clean_y = self.cache[index]

        if apply_transform and self.training_transforms is not None:
            X = self.training_transforms(X)

        if apply_attack and self.is_poisoned(index):
            X = self.attack(X)

        if use_original_label:
            y = int(clean_y)
        else:
            y = self._poison_label_if_needed(clean_y, index)

        return X, y

    def load(self) -> None:
        self.cache = []

        for img_path, y in zip(self.X, self.original_y):
            x = Image.open(img_path).convert("L")
            x = self.loading_transforms(x)
            self.cache.append((x, int(y)))

        self.y = list(self.original_y)
        return


def get_federation(
    num_shards: int,
    alpha: float,
    attacks: Optional[list[Attack]] = None,
    attacks_proba: float = 0.0,
    poison_rate: float = 0.10,
    seed: int = 42,
    use_standard_aug: bool = True,
    attack_assignment: str = "random",
    auto_download: bool = True,
) -> list[Dict[str, Dataset]]:
    """
    构建 Fashion-MNIST 联邦数据。

    使用示例：
        federation = get_federation(
            num_shards=100,
            alpha=0.5,
            attacks=[BadNets(target_label=0)],
            attacks_proba=0.3,
            poison_rate=0.1,
            seed=11,
        )
    """
    if auto_download:
        prepare_fashion_mnist_png(force=False)

    Dataset._auto_client_counter = 0
    attacks = attacks or []

    dataset_class = partial(
        Dataset,
        poison_rate=poison_rate,
        seed=seed,
        use_standard_aug=use_standard_aug,
    )

    sampler = FederationSampler(TRAIN_DATA_PATH, TEST_DATA_PATH, "png", 10)
    federation = sampler.sample_federation(
        dataset_class,
        num_shards,
        alpha,
        attacks,
        attacks_proba,
        attack_assignment=attack_assignment,
    )
    return federation
