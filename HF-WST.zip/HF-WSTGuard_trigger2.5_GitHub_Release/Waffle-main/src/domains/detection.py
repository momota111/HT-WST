from dataclasses import dataclass
from typing import Any, Optional
from sklearn.metrics.pairwise import cosine_distances
from sklearn.cluster import KMeans
import numpy as np
import torch


@dataclass
class DetectionResult:
    malicious_clients: list[int]
    suspicion_scores: torch.Tensor
    malicious_votes: torch.Tensor
    participated_classes: torch.Tensor
    logs: list[dict[str, Any]]


def _safe_l2_normalize(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    norms = np.linalg.norm(X, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    return X / norms


def _make_direction_energy_features(X: np.ndarray, energy_weight: float = 1.5) -> np.ndarray:
    """
    方向 + 高频能量特征。
    比纯 L2 更适合标准低投毒后门，因为 trigger 可能体现为高频能量增强。
    """
    X = np.asarray(X, dtype=np.float64)

    norms = np.linalg.norm(X, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)

    direction = X / norms

    log_energy = np.log1p(norms)
    log_energy = (log_energy - log_energy.mean()) / (log_energy.std() + 1e-12)

    feature = np.concatenate([direction, energy_weight * log_energy], axis=1)
    return _safe_l2_normalize(feature)


def _cluster_spread(features: np.ndarray) -> float:
    if len(features) <= 1:
        return 0.0
    return float(np.mean(cosine_distances(features)))


def class_conditional_wst_hf_kmeans(
    federation_features: torch.Tensor,
    num_classes: int = 10,
    valid_class_mask: Optional[torch.Tensor] = None,

    min_clients_per_class: int = 5,
    min_suspicious_cluster_size: int = 2,
    min_suspicious_cluster_ratio: float = 0.05,
    max_suspicious_cluster_ratio: float = 0.45,

    spread_threshold: float = 0.20,
    gap_threshold: float = 1.20,
    vote_threshold: float = 0.125,

    feature_mode: str = "direction_energy",
    energy_weight: float = 1.5,

    random_state: int = 42,
    return_details: bool = False,
):
    """
    改进版 WST-HF-KMeans 检测器。

    相比旧版：
    1. 不再单类别命中就直接拉黑；
    2. 改为跨类别投票，降低误杀；
    3. 支持 valid_class_mask；
    4. 支持 direction_energy 特征；
    5. 返回详细日志，方便分析 FP。
    """

    if federation_features.dim() != 3:
        raise ValueError("federation_features must have shape [num_clients, num_classes, feature_dim]")

    num_clients = federation_features.size(0)
    device = federation_features.device

    malicious_votes = torch.zeros(num_clients, dtype=torch.float32, device=device)
    participated_classes = torch.zeros(num_clients, dtype=torch.float32, device=device)
    logs = []

    for c in range(num_classes):
        class_c_features = federation_features[:, c, :]

        if valid_class_mask is not None:
            valid_mask = valid_class_mask[:, c].to(device).bool()
        else:
            valid_mask = class_c_features.abs().sum(dim=1) > 1e-8

        valid_idx = torch.where(valid_mask)[0].detach().cpu().tolist()
        N = len(valid_idx)

        if N > 0:
            participated_classes[valid_mask] += 1

        if N < min_clients_per_class:
            logs.append({
                "class_id": c,
                "status": "skip_too_few_clients",
                "num_valid_clients": N,
            })
            continue

        valid_features = class_c_features[valid_mask].detach().cpu().numpy()

        if feature_mode == "direction_energy":
            valid_features_norm = _make_direction_energy_features(
                valid_features,
                energy_weight=energy_weight,
            )
        else:
            valid_features_norm = _safe_l2_normalize(valid_features)

        if np.std(valid_features_norm) < 1e-12:
            logs.append({
                "class_id": c,
                "status": "skip_degenerate_features",
                "num_valid_clients": N,
            })
            continue

        kmeans = KMeans(n_clusters=5, n_init=10, random_state=random_state)
        preds = kmeans.fit_predict(valid_features_norm)

        feats_0 = valid_features_norm[preds == 0]
        feats_1 = valid_features_norm[preds == 1]

        spread_0 = _cluster_spread(feats_0)
        spread_1 = _cluster_spread(feats_1)

        size_0 = int(np.sum(preds == 0))
        size_1 = int(np.sum(preds == 1))

        # 更紧密的簇作为候选恶意簇
        if spread_0 <= spread_1:
            suspicious_cluster = 0
            suspicious_spread = spread_0
            other_spread = spread_1
            suspicious_size = size_0
            other_size = size_1
        else:
            suspicious_cluster = 1
            suspicious_spread = spread_1
            other_spread = spread_0
            suspicious_size = size_1
            other_size = size_0

        gap_ratio = float(other_spread / (suspicious_spread + 1e-12))
        suspicious_ratio = suspicious_size / max(N, 1)

        pass_spread = suspicious_spread < spread_threshold
        pass_gap = gap_ratio > gap_threshold
        pass_size = suspicious_size >= min_suspicious_cluster_size
        pass_ratio = (
            suspicious_ratio >= min_suspicious_cluster_ratio
            and suspicious_ratio <= max_suspicious_cluster_ratio
        )

        pass_gate = pass_spread and pass_gap and pass_size and pass_ratio

        voted_clients = []
        if pass_gate:
            suspicious_local_idx = np.where(preds == suspicious_cluster)[0]

            for local_idx in suspicious_local_idx:
                global_idx = valid_idx[int(local_idx)]
                malicious_votes[global_idx] += 1
                voted_clients.append(global_idx)

        logs.append({
            "class_id": c,
            "status": "voted" if pass_gate else "skip_gate_not_satisfied",
            "num_valid_clients": N,

            "cluster0_size": size_0,
            "cluster1_size": size_1,
            "cluster0_spread": float(spread_0),
            "cluster1_spread": float(spread_1),

            "suspicious_cluster": int(suspicious_cluster),
            "suspicious_size": int(suspicious_size),
            "other_size": int(other_size),
            "suspicious_ratio": float(suspicious_ratio),
            "suspicious_spread": float(suspicious_spread),
            "other_spread": float(other_spread),
            "gap_ratio": float(gap_ratio),

            "pass_spread": bool(pass_spread),
            "pass_gap": bool(pass_gap),
            "pass_size": bool(pass_size),
            "pass_ratio": bool(pass_ratio),

            "voted_clients": voted_clients,
        })

    suspicion_scores = malicious_votes / (participated_classes + 1e-12)

    malicious_clients = torch.where(
        suspicion_scores >= vote_threshold
    )[0].detach().cpu().tolist()

    result = DetectionResult(
        malicious_clients=malicious_clients,
        suspicion_scores=suspicion_scores.detach().cpu(),
        malicious_votes=malicious_votes.detach().cpu(),
        participated_classes=participated_classes.detach().cpu(),
        logs=logs,
    )

    if return_details:
        return result

    return malicious_clients