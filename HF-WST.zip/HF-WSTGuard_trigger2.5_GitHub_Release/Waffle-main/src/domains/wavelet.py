from __future__ import annotations

from random import shuffle
from typing import Any, Literal, Optional

import numpy as np
import torch
from kymatio.torch import Scattering2D
from torch import stack

from src.data.base import BaseDataset

BandType = Literal["high", "full", "low_mid"]
PoolType = Literal["max", "mean", "none"]
AggregationType = Literal["mean_image", "mean_wst", "topk_energy"]
LabelSource = Literal["original", "observed", "pseudo"]


def _to_gray(X: torch.Tensor) -> torch.Tensor:
    if X.dim() == 4 and X.size(1) > 1:
        return 0.2989 * X[:, 0] + 0.5870 * X[:, 1] + 0.1140 * X[:, 2]
    if X.dim() == 4:
        return X[:, 0]
    if X.dim() == 3:
        return X
    raise ValueError(f"Unexpected image tensor shape: {tuple(X.shape)}")


def _select_wst_band(Sx: torch.Tensor, J_wst: int, L_wst: int, band: BandType) -> torch.Tensor:
    if band == "full":
        return Sx

    num_low_mid_channels = 1 + J_wst * L_wst

    if band == "high":
        if Sx.size(1) > num_low_mid_channels:
            return Sx[:, num_low_mid_channels:, :, :]
        return Sx[:, 1:, :, :]

    if band == "low_mid":
        end = min(num_low_mid_channels, Sx.size(1))
        return Sx[:, :end, :, :]

    raise ValueError(f"Unknown WST band: {band}")


def _pool_wst(Sx: torch.Tensor, pooling: PoolType) -> torch.Tensor:
    if pooling == "max":
        return torch.nn.functional.adaptive_max_pool2d(Sx, (1, 1))
    if pooling == "mean":
        return torch.nn.functional.adaptive_avg_pool2d(Sx, (1, 1))
    if pooling == "none":
        return Sx
    raise ValueError(f"Unknown pooling type: {pooling}")


def _scatter_in_batches(scattering: Scattering2D, X: torch.Tensor, batch_size: int = 64) -> torch.Tensor:
    outputs = []
    for start in range(0, X.size(0), batch_size):
        end = min(start + batch_size, X.size(0))
        outputs.append(scattering(X[start:end].contiguous()))
    return torch.cat(outputs, dim=0)


def _read_detection_image(
    dataset: BaseDataset,
    index: int,
    apply_attack: bool,
    apply_transform: bool,
) -> torch.Tensor:
    """
    读取检测模块实际看到的图像，不使用任何客户端标签。

    优先调用新版 get_detection_image()；为了兼容旧数据集，若不存在该接口，
    则调用 get_detection_item() 但丢弃其标签返回值。
    """
    if hasattr(dataset, "get_detection_image"):
        return dataset.get_detection_image(
            index,
            apply_attack=apply_attack,
            apply_transform=apply_transform,
        )

    if hasattr(dataset, "get_detection_item"):
        X, _ = dataset.get_detection_item(
            index,
            use_original_label=False,
            apply_attack=apply_attack,
            apply_transform=apply_transform,
        )
        return X

    X, _ = dataset[index]
    return X


def _collect_all_detection_images(
    dataset: BaseDataset,
    apply_attack: bool = True,
    apply_transform: bool = False,
) -> list[torch.Tensor]:
    if len(dataset.cache) == 0:
        dataset.load()

    return [
        _read_detection_image(
            dataset=dataset,
            index=i,
            apply_attack=apply_attack,
            apply_transform=apply_transform,
        )
        for i in range(len(dataset))
    ]


def _collect_class_images_legacy(
    dataset: BaseDataset,
    target_class: int,
    label_source: Literal["original", "observed"],
    apply_attack: bool = True,
    apply_transform: bool = False,
    max_samples: Optional[int] = None,
) -> list[torch.Tensor]:
    """
    仅用于历史对照：按照原始标签或投毒后可见标签分组。
    正式伪标签实验应使用 label_source="pseudo"。
    """
    if len(dataset.cache) == 0:
        dataset.load()

    imgs: list[torch.Tensor] = []
    use_original_label = label_source == "original"

    for i in range(len(dataset)):
        if hasattr(dataset, "get_detection_item"):
            X, y = dataset.get_detection_item(
                i,
                use_original_label=use_original_label,
                apply_attack=apply_attack,
                apply_transform=apply_transform,
            )
        else:
            X, y = dataset[i]

        if int(y) == int(target_class):
            imgs.append(X)
            if max_samples is not None and len(imgs) >= max_samples:
                break

    return imgs


@torch.no_grad()
def _predict_pseudo_labels(
    model: torch.nn.Module,
    images: list[torch.Tensor],
    device: str,
    batch_size: int = 128,
    confidence_threshold: float = 0.0,
    temperature: float = 1.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    使用冻结的当前全局模型预测伪标签。

    返回：
        pseudo_labels: [N]
        confidences:   [N]
        accepted_mask: [N]，置信度低于阈值的样本不参与类别条件化
    """
    if model is None:
        raise ValueError('label_source="pseudo" 时必须提供 pseudo_label_model。')
    if len(images) == 0:
        return (
            torch.empty(0, dtype=torch.long),
            torch.empty(0, dtype=torch.float32),
            torch.empty(0, dtype=torch.bool),
        )
    if temperature <= 0:
        raise ValueError("pseudo_label_temperature 必须大于 0。")
    if not 0.0 <= confidence_threshold <= 1.0:
        raise ValueError("pseudo_conf_threshold 必须位于 [0, 1]。")

    was_training = model.training
    model = model.to(device)
    model.eval()

    pred_list: list[torch.Tensor] = []
    conf_list: list[torch.Tensor] = []

    for start in range(0, len(images), batch_size):
        end = min(start + batch_size, len(images))
        X = torch.stack(images[start:end]).float().to(device)
        logits = model(X)
        if logits.dim() != 2:
            raise ValueError(f"伪标签模型输出必须为 [N,C]，实际为 {tuple(logits.shape)}")
        probs = torch.softmax(logits / temperature, dim=1)
        conf, pred = probs.max(dim=1)
        pred_list.append(pred.detach().cpu())
        conf_list.append(conf.detach().cpu())

    model.train(was_training)

    pseudo_labels = torch.cat(pred_list, dim=0).long()
    confidences = torch.cat(conf_list, dim=0).float()
    accepted_mask = confidences >= float(confidence_threshold)
    return pseudo_labels, confidences, accepted_mask


def _pseudo_label_groups(
    images: list[torch.Tensor],
    pseudo_labels: torch.Tensor,
    accepted_mask: torch.Tensor,
    num_classes: int,
    max_samples_per_class: Optional[int],
) -> list[list[torch.Tensor]]:
    groups: list[list[torch.Tensor]] = [[] for _ in range(num_classes)]

    for i, X in enumerate(images):
        if not bool(accepted_mask[i]):
            continue
        c = int(pseudo_labels[i].item())
        if c < 0 or c >= num_classes:
            raise ValueError(f"伪标签越界：label={c}, num_classes={num_classes}")
        if max_samples_per_class is None or len(groups[c]) < max_samples_per_class:
            groups[c].append(X)

    return groups


def _pseudo_label_diagnostics(
    pseudo_labels: torch.Tensor,
    confidences: torch.Tensor,
    accepted_mask: torch.Tensor,
    num_classes: int,
) -> dict[str, Any]:
    accepted_labels = pseudo_labels[accepted_mask]
    counts = torch.bincount(accepted_labels, minlength=num_classes).cpu().numpy().astype(int)
    accepted = int(accepted_mask.sum().item())
    total = int(len(pseudo_labels))

    if accepted > 0:
        probs = counts.astype(np.float64) / accepted
        nz = probs[probs > 0]
        entropy = float(-(nz * np.log(nz + 1e-12)).sum())
        dominant_ratio = float(counts.max() / accepted)
        mean_conf = float(confidences[accepted_mask].mean().item())
        min_conf = float(confidences[accepted_mask].min().item())
    else:
        entropy = 0.0
        dominant_ratio = 0.0
        mean_conf = 0.0
        min_conf = 0.0

    return {
        "num_samples": total,
        "num_accepted": accepted,
        "num_rejected": total - accepted,
        "acceptance_rate": accepted / max(total, 1),
        "mean_accepted_confidence": mean_conf,
        "min_accepted_confidence": min_conf,
        "per_class_counts": counts.tolist(),
        "num_nonempty_pseudo_classes": int((counts > 0).sum()),
        "dominant_class_ratio": dominant_ratio,
        "pseudo_label_entropy": entropy,
    }


def _extract_wst_feature_from_images(
    X: torch.Tensor,
    scattering: Scattering2D,
    J_wst: int,
    L_wst: int,
    device: str,
    band: BandType = "high",
    pooling: PoolType = "max",
    aggregation: AggregationType = "topk_energy",
    topk_ratio: float = 0.20,
    wst_batch_size: int = 64,
) -> torch.Tensor:
    if X.dim() != 3:
        raise ValueError(f"Expected grayscale X with shape [N,H,W], got {tuple(X.shape)}")

    X = X.float().to(device)
    num_imgs, height, width = X.size()

    if aggregation == "mean_image":
        mean_img = torch.mean(X, dim=0).view(1, height, width)
        with torch.no_grad():
            Sx = scattering(mean_img.contiguous())
            Sx = _select_wst_band(Sx, J_wst, L_wst, band)
            Sx = _pool_wst(Sx, pooling)
            return Sx.contiguous().view(-1).cpu()

    if aggregation in {"mean_wst", "topk_energy"}:
        with torch.no_grad():
            Sx_all = _scatter_in_batches(scattering, X, batch_size=wst_batch_size)
            Sx_all = _select_wst_band(Sx_all, J_wst, L_wst, band)

            if aggregation == "topk_energy":
                energy_map = torch.nn.functional.adaptive_max_pool2d(Sx_all, (1, 1))
                energy_score = energy_map.view(energy_map.size(0), -1).mean(dim=1)

                k = max(1, int(round(topk_ratio * num_imgs)))
                k = min(k, num_imgs)
                top_idx = torch.topk(energy_score, k=k, largest=True).indices
                Sx_selected = Sx_all[top_idx]
            else:
                Sx_selected = Sx_all

            Sx_agg = Sx_selected.mean(dim=0, keepdim=True)
            Sx_agg = _pool_wst(Sx_agg, pooling)
            return Sx_agg.contiguous().view(-1).cpu()

    raise ValueError(f"Unknown aggregation: {aggregation}")


def get_dataset_domain(
    dataset: BaseDataset,
    J_wst: int = 2,
    L_wst: int = 8,
    sample_size: float = 1.0,
    device: str = "cpu",
    band: BandType = "high",
    pooling: PoolType = "none",
) -> torch.Tensor:
    N = len(dataset)
    num_samples = max(2, int(sample_size * N))

    dataset.load()
    indexes = list(range(len(dataset.cache)))
    shuffle(indexes)
    imgs = [dataset.cache[i][0] for i in indexes[:num_samples]]
    dataset.clear()

    X = stack(imgs)
    X = _to_gray(X)
    _, height, width = X.size()

    mean_img = torch.mean(X, dim=0).view(1, height, width).float().to(device)
    wst = Scattering2D(J=J_wst, shape=(height, width), L=L_wst).to(device)

    with torch.no_grad():
        Sx = wst(mean_img.contiguous())
        Sx = _select_wst_band(Sx, J_wst, L_wst, band)
        Sx = _pool_wst(Sx, pooling)
        feature = Sx.contiguous().view(-1).cpu()

    return feature


def get_dataset_domain_class_conditional(
    dataset: BaseDataset,
    num_classes: int = 10,
    J_wst: int = 2,
    L_wst: int = 8,
    device: str = "cpu",
    band: BandType = "high",
    pooling: PoolType = "max",
    label_source: LabelSource = "original",
    pseudo_label_model: Optional[torch.nn.Module] = None,
    pseudo_label_device: Optional[str] = None,
    pseudo_label_batch_size: int = 128,
    pseudo_conf_threshold: float = 0.0,
    pseudo_label_temperature: float = 1.0,
    use_original_label: Optional[bool] = None,
    apply_attack: bool = True,
    apply_transform: bool = False,
    min_samples_per_class: int = 2,
    max_samples_per_class: Optional[int] = None,
    aggregation: AggregationType = "topk_energy",
    topk_ratio: float = 0.20,
    wst_batch_size: int = 64,
    return_valid_mask: bool = False,
    return_diagnostics: bool = False,
):
    """
    Class-Conditional WST 特征提取。

    正式伪标签协议：
        label_source="pseudo"
        pseudo_label_model=<冻结的当前全局模型>
        apply_attack=True
        apply_transform=False

    此时类别分组只由模型预测产生，不读取 original_y 或 poisoned_y。

    use_original_label 仅用于兼容旧 Notebook：
        True  -> label_source="original"
        False -> label_source="observed"
    新正式实验不要传该参数。
    """
    if use_original_label is not None:
        label_source = "original" if use_original_label else "observed"

    if label_source not in {"original", "observed", "pseudo"}:
        raise ValueError(f"Unknown label_source: {label_source}")

    dataset.load()
    class_features: list[Optional[torch.Tensor]] = []
    valid_mask: list[bool] = []
    scattering: Optional[Scattering2D] = None
    feature_dim: Optional[int] = None
    diagnostics: dict[str, Any] = {"label_source": label_source}

    if label_source == "pseudo":
        images = _collect_all_detection_images(
            dataset,
            apply_attack=apply_attack,
            apply_transform=apply_transform,
        )
        pseudo_labels, confidences, accepted_mask = _predict_pseudo_labels(
            model=pseudo_label_model,
            images=images,
            device=pseudo_label_device or device,
            batch_size=pseudo_label_batch_size,
            confidence_threshold=pseudo_conf_threshold,
            temperature=pseudo_label_temperature,
        )
        groups = _pseudo_label_groups(
            images=images,
            pseudo_labels=pseudo_labels,
            accepted_mask=accepted_mask,
            num_classes=num_classes,
            max_samples_per_class=max_samples_per_class,
        )
        diagnostics.update(
            _pseudo_label_diagnostics(
                pseudo_labels=pseudo_labels,
                confidences=confidences,
                accepted_mask=accepted_mask,
                num_classes=num_classes,
            )
        )
    else:
        groups = [
            _collect_class_images_legacy(
                dataset=dataset,
                target_class=c,
                label_source=label_source,
                apply_attack=apply_attack,
                apply_transform=apply_transform,
                max_samples=max_samples_per_class,
            )
            for c in range(num_classes)
        ]
        diagnostics["per_class_counts"] = [len(x) for x in groups]

    for c in range(num_classes):
        imgs = groups[c]

        if len(imgs) < min_samples_per_class:
            class_features.append(None)
            valid_mask.append(False)
            continue

        X = torch.stack(imgs)
        X = _to_gray(X)
        _, height, width = X.size()

        if scattering is None:
            scattering = Scattering2D(J=J_wst, L=L_wst, shape=(height, width)).to(device)

        phi_c = _extract_wst_feature_from_images(
            X=X,
            scattering=scattering,
            J_wst=J_wst,
            L_wst=L_wst,
            device=device,
            band=band,
            pooling=pooling,
            aggregation=aggregation,
            topk_ratio=topk_ratio,
            wst_batch_size=wst_batch_size,
        )

        feature_dim = phi_c.numel() if feature_dim is None else feature_dim
        class_features.append(phi_c)
        valid_mask.append(True)

    dataset.clear()

    if feature_dim is None:
        raise ValueError(
            "该客户端没有任何有效伪类别。请检查全局模型质量、"
            "pseudo_conf_threshold 和 min_samples_per_class。"
        )

    for i in range(num_classes):
        if class_features[i] is None:
            class_features[i] = torch.zeros(feature_dim)

    features = torch.stack([x for x in class_features if x is not None])
    valid_mask_tensor = torch.tensor(valid_mask, dtype=torch.bool)
    diagnostics["valid_class_mask"] = valid_mask_tensor.tolist()
    diagnostics["num_valid_classes"] = int(valid_mask_tensor.sum().item())

    outputs: list[Any] = [features]
    if return_valid_mask:
        outputs.append(valid_mask_tensor)
    if return_diagnostics:
        outputs.append(diagnostics)

    if len(outputs) == 1:
        return outputs[0]
    return tuple(outputs)


def build_federation_wst_features(
    federation: list[dict],
    split: str = "train",
    num_classes: int = 10,
    J_wst: int = 2,
    L_wst: int = 8,
    device: str = "cpu",
    band: BandType = "high",
    pooling: PoolType = "max",
    label_source: LabelSource = "original",
    pseudo_label_model: Optional[torch.nn.Module] = None,
    pseudo_label_device: Optional[str] = None,
    pseudo_label_batch_size: int = 128,
    pseudo_conf_threshold: float = 0.0,
    pseudo_label_temperature: float = 1.0,
    use_original_label: Optional[bool] = None,
    apply_attack: bool = True,
    apply_transform: bool = False,
    min_samples_per_class: int = 2,
    max_samples_per_class: Optional[int] = None,
    aggregation: AggregationType = "topk_energy",
    topk_ratio: float = 0.20,
    wst_batch_size: int = 64,
    return_diagnostics: bool = False,
):
    """
    构建联邦客户端的 WST 特征。

    新正式调用示例：
        features, valid_masks, diagnostics = build_federation_wst_features(
            federation,
            label_source="pseudo",
            pseudo_label_model=frozen_global_model,
            return_diagnostics=True,
            ...
        )
    """
    features: list[torch.Tensor] = []
    valid_masks: list[torch.Tensor] = []
    all_diagnostics: list[dict[str, Any]] = []

    for client_id, item in enumerate(federation):
        result = get_dataset_domain_class_conditional(
            item[split],
            num_classes=num_classes,
            J_wst=J_wst,
            L_wst=L_wst,
            device=device,
            band=band,
            pooling=pooling,
            label_source=label_source,
            pseudo_label_model=pseudo_label_model,
            pseudo_label_device=pseudo_label_device,
            pseudo_label_batch_size=pseudo_label_batch_size,
            pseudo_conf_threshold=pseudo_conf_threshold,
            pseudo_label_temperature=pseudo_label_temperature,
            use_original_label=use_original_label,
            apply_attack=apply_attack,
            apply_transform=apply_transform,
            min_samples_per_class=min_samples_per_class,
            max_samples_per_class=max_samples_per_class,
            aggregation=aggregation,
            topk_ratio=topk_ratio,
            wst_batch_size=wst_batch_size,
            return_valid_mask=True,
            return_diagnostics=return_diagnostics,
        )

        if return_diagnostics:
            client_features, client_valid_mask, diagnostics = result
            diagnostics = dict(diagnostics)
            diagnostics["client_id"] = int(client_id)
            all_diagnostics.append(diagnostics)
        else:
            client_features, client_valid_mask = result

        features.append(client_features)
        valid_masks.append(client_valid_mask)

    feature_tensor = torch.stack(features)
    mask_tensor = torch.stack(valid_masks)

    if return_diagnostics:
        return feature_tensor, mask_tensor, all_diagnostics
    return feature_tensor, mask_tensor
