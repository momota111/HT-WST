"""
HDBSCAN-enhanced detector for DBA-style distributed backdoor triggers.

Why this file exists:
- KMeans(n_clusters=2) assumes one benign cluster + one malicious cluster.
- DBA often creates several weak sub-trigger groups, so a density-based
  multi-cluster detector is a better candidate generator.

Usage:
    from src.domains.detection_hdbscan import class_conditional_wst_hf_hdbscan
"""

from dataclasses import dataclass
from typing import Any, Optional, Tuple

import numpy as np
import torch
from sklearn.metrics.pairwise import cosine_distances


@dataclass
class DetectionResult:
    malicious_clients: list[int]
    suspicion_scores: torch.Tensor
    malicious_votes: torch.Tensor
    participated_classes: torch.Tensor
    logs: list[dict[str, Any]]


def _safe_l2_normalize(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    norms = np.linalg.norm(X, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    return X / norms


def _make_direction_energy_features(X: np.ndarray, energy_weight: float = 1.5) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    norms = np.linalg.norm(X, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    direction = X / norms
    log_energy = np.log1p(norms)
    log_energy = (log_energy - log_energy.mean()) / (log_energy.std() + 1e-12)
    feature = np.concatenate([direction, energy_weight * log_energy], axis=1)
    return _safe_l2_normalize(feature)


def _energy_zscore(X: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(np.asarray(X, dtype=np.float64), axis=1)
    log_energy = np.log1p(np.maximum(norms, 1e-12))
    return (log_energy - log_energy.mean()) / (log_energy.std() + 1e-12)


def _cluster_spread(features: np.ndarray) -> float:
    if len(features) <= 1:
        return 0.0
    return float(np.mean(cosine_distances(features)))


def _fit_hdbscan(
    X: np.ndarray,
    min_cluster_size: int = 3,
    min_samples: int = 1,
    metric: str = "euclidean",
) -> Tuple[np.ndarray, np.ndarray | None, str]:
    """Fit HDBSCAN using sklearn if available, otherwise hdbscan package."""
    try:
        from sklearn.cluster import HDBSCAN as SklearnHDBSCAN

        clusterer = SklearnHDBSCAN(
            min_cluster_size=min_cluster_size,
            min_samples=min_samples,
            metric=metric,
            cluster_selection_method="eom",
            allow_single_cluster=False,
        )
        labels = clusterer.fit_predict(X)
        # sklearn HDBSCAN does not consistently expose GLOSH outlier scores.
        scores = getattr(clusterer, "outlier_scores_", None)
        return labels, scores, "sklearn.cluster.HDBSCAN"
    except Exception:
        pass

    try:
        import hdbscan

        clusterer = hdbscan.HDBSCAN(
            min_cluster_size=min_cluster_size,
            min_samples=min_samples,
            metric=metric,
            cluster_selection_method="eom",
            prediction_data=False,
        )
        labels = clusterer.fit_predict(X)
        scores = getattr(clusterer, "outlier_scores_", None)
        return labels, scores, "hdbscan.HDBSCAN"
    except Exception as e:
        raise ImportError(
            "HDBSCAN is not available. Please install one of the following:\n"
            "  pip install -U scikit-learn\n"
            "or\n"
            "  pip install hdbscan\n"
            f"Original error: {repr(e)}"
        )


def class_conditional_wst_hf_hdbscan(
    federation_features: torch.Tensor,
    num_classes: int = 10,
    valid_class_mask: Optional[torch.Tensor] = None,

    min_clients_per_class: int = 5,
    min_cluster_size: int = 3,
    min_samples: int = 1,

    # Candidate filtering. DBA needs looser filtering than BadNets.
    min_candidate_size: int = 1,
    max_candidate_ratio: float = 0.2,
    min_energy_z: float = 0.80,
    vote_threshold: float = 0.10,

    # Add high-outlier-score points if hdbscan package exposes GLOSH scores.
    use_outlier_scores: bool = True,
    outlier_quantile: float = 0.85,

    feature_mode: str = "direction_energy",
    energy_weight: float = 1.5,
    metric: str = "euclidean",

    return_details: bool = False,
):
    """
    DBA-oriented WST-HF-HDBSCAN detector.

    Detection logic per class:
    1. Build direction + log-energy feature for each valid client.
    2. Run HDBSCAN to obtain multiple clusters plus noise points.
    3. Vote for clients in:
       - noise group with acceptable size and non-low energy;
       - small clusters with non-low energy;
       - high HDBSCAN outlier-score points if available.
    4. Aggregate votes across classes.

    Recommended first DBA parameters:
        min_cluster_size=3, min_samples=1,
        min_energy_z=-0.25, vote_threshold=0.08,
        max_candidate_ratio=0.45.
    """
    if federation_features.dim() != 3:
        raise ValueError("federation_features must have shape [num_clients, num_classes, feature_dim]")

    num_clients = federation_features.size(0)
    device = federation_features.device

    malicious_votes = torch.zeros(num_clients, dtype=torch.float32, device=device)
    participated_classes = torch.zeros(num_clients, dtype=torch.float32, device=device)
    logs: list[dict[str, Any]] = []

    backend_name = None

    for c in range(num_classes):
        class_c_features = federation_features[:, c, :]

        if valid_class_mask is not None:
            valid_mask = valid_class_mask[:, c].to(device).bool()
        else:
            valid_mask = class_c_features.abs().sum(dim=1) > 1e-8

        valid_idx = torch.where(valid_mask)[0].detach().cpu().tolist()
        N = len(valid_idx)

        if N > 0:
            participated_classes[valid_mask] += 1

        if N < min_clients_per_class:
            logs.append({
                "class_id": c,
                "status": "skip_too_few_clients",
                "num_valid_clients": N,
            })
            continue

        valid_features = class_c_features[valid_mask].detach().cpu().numpy()
        energy_z = _energy_zscore(valid_features)

        if feature_mode == "direction_energy":
            X = _make_direction_energy_features(valid_features, energy_weight=energy_weight)
        else:
            X = _safe_l2_normalize(valid_features)

        if np.std(X) < 1e-12:
            logs.append({
                "class_id": c,
                "status": "skip_degenerate_features",
                "num_valid_clients": N,
            })
            continue

        labels, outlier_scores, backend_name = _fit_hdbscan(
            X,
            min_cluster_size=min_cluster_size,
            min_samples=min_samples,
            metric=metric,
        )

        candidate_local: set[int] = set()
        cluster_infos = []

        unique_labels = sorted(set(int(x) for x in labels.tolist()))
        for lab in unique_labels:
            local_ids = np.where(labels == lab)[0]
            size = int(len(local_ids))
            ratio = size / max(N, 1)
            mean_energy = float(np.mean(energy_z[local_ids])) if size > 0 else -999.0
            spread = _cluster_spread(X[local_ids]) if size > 0 else 999.0

            # Noise label -1 is a natural suspicious candidate, but only when not too large.
            if lab == -1:
                is_candidate = (
                    size >= min_candidate_size
                    and ratio <= max_candidate_ratio
                    and mean_energy >= min_energy_z
                )
            else:
                # DBA may create several small dense sub-trigger clusters.
                is_candidate = (
                    size >= min_candidate_size
                    and ratio <= max_candidate_ratio
                    and mean_energy >= min_energy_z
                )

            if is_candidate:
                for local_idx in local_ids:
                    candidate_local.add(int(local_idx))

            cluster_infos.append({
                "label": int(lab),
                "size": size,
                "ratio": float(ratio),
                "mean_energy_z": mean_energy,
                "spread": float(spread),
                "is_candidate": bool(is_candidate),
            })

        # Add high-outlier-score points, if available.
        outlier_threshold = None
        if use_outlier_scores and outlier_scores is not None:
            outlier_scores = np.asarray(outlier_scores, dtype=np.float64)
            if np.all(np.isfinite(outlier_scores)) and np.std(outlier_scores) > 1e-12:
                outlier_threshold = float(np.quantile(outlier_scores, outlier_quantile))
                high_outlier_ids = np.where(
                    (outlier_scores >= outlier_threshold) & (energy_z >= min_energy_z)
                )[0]
                for local_idx in high_outlier_ids:
                    candidate_local.add(int(local_idx))

        voted_clients = []
        for local_idx in sorted(candidate_local):
            global_idx = valid_idx[int(local_idx)]
            malicious_votes[global_idx] += 1
            voted_clients.append(global_idx)

        logs.append({
            "class_id": c,
            "status": "voted" if len(voted_clients) > 0 else "no_candidate",
            "num_valid_clients": N,
            "backend": backend_name,
            "num_clusters_excluding_noise": int(len([x for x in unique_labels if x != -1])),
            "num_noise": int(np.sum(labels == -1)),
            "cluster_infos": cluster_infos,
            "min_energy_z": float(min_energy_z),
            "outlier_threshold": outlier_threshold,
            "voted_clients": voted_clients,
        })

    suspicion_scores = malicious_votes / (participated_classes + 1e-12)
    malicious_clients = torch.where(suspicion_scores >= vote_threshold)[0].detach().cpu().tolist()

    result = DetectionResult(
        malicious_clients=malicious_clients,
        suspicion_scores=suspicion_scores.detach().cpu(),
        malicious_votes=malicious_votes.detach().cpu(),
        participated_classes=participated_classes.detach().cpu(),
        logs=logs,
    )

    if return_details:
        return result
    return malicious_clients

# ============================================================
# Risk-aware aggregation interface
# ============================================================

def build_risk_scores(
    suspicion_scores: torch.Tensor,
    temperature: float = 1.0,
    eps: float = 1e-12,
):
    """
    Convert detection suspicion scores into
    continuous client risk scores for Risk-aware FedAvg.

    Args:
        suspicion_scores:
            Tensor [num_clients]

            Original HDBSCAN voting score.

        temperature:
            Controls risk sharpness.

        eps:
            Numerical stability.


    Returns:
        risk_scores:
            Tensor [num_clients]

            Range:
                [0,1]

            Larger value means
            higher probability of malicious behavior.
    """

    scores = suspicion_scores.float().clone()

    if scores.numel() == 0:
        return scores


    # normalize to [0,1]
    min_v = scores.min()
    max_v = scores.max()


    if (max_v - min_v) < eps:
        risk = torch.zeros_like(scores)

    else:
        risk = (
            (scores - min_v)
            /
            (max_v - min_v + eps)
        )


    # temperature sharpening

    risk = torch.sigmoid(
        temperature *
        (risk - 0.5) * 5
    )


    return risk



def detection_result_to_risk(
    detection_result,
    temperature: float = 1.0,
):
    """
    Convert DetectionResult into
    Risk-aware FedAvg input.
    """

    if hasattr(
        detection_result,
        "suspicion_scores"
    ):

        suspicion_scores = (
            detection_result.suspicion_scores
        )

    else:

        raise ValueError(
            "Detection result does not contain suspicion_scores"
        )


    risk_scores = build_risk_scores(
        suspicion_scores,
        temperature=temperature,
    )


    return {
        "risk_scores": risk_scores,

        "malicious_clients":
            detection_result.malicious_clients,

        "suspicion_scores":
            suspicion_scores,
    }