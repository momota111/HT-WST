# CIFAR-10 data directory

The code expects PNG files under:

- `train/`
- `test/`

File names must contain `_y<label>.png`, e.g. `img_00000_y6.png`.

Run `python scripts/prepare_cifar10_png.py` from the repository root to create the dataset.

For exact reproduction of the locked paper seeds/client partitions, use the same prepared CIFAR-10 PNG asset used in the formal runs when available.
