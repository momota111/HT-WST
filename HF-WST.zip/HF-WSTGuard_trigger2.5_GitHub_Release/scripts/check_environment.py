import importlib
mods=['torch','torchvision','numpy','pandas','sklearn','kymatio','PIL','tqdm','matplotlib']
for m in mods:
    try:
        mod=importlib.import_module(m)
        print(f'[OK] {m}:', getattr(mod,'__version__',''))
    except Exception as e:
        print(f'[MISSING] {m}: {e}')
