from pathlib import Path
from torchvision.datasets import CIFAR10
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'Waffle-main' / 'data' / 'cifar10'
TRAIN = OUT / 'train'
TEST = OUT / 'test'
TRAIN.mkdir(parents=True, exist_ok=True)
TEST.mkdir(parents=True, exist_ok=True)

print('Downloading CIFAR-10...')
raw_root = ROOT / '.cifar10_raw'
train_ds = CIFAR10(root=raw_root, train=True, download=True)
test_ds = CIFAR10(root=raw_root, train=False, download=True)

for split_name, ds, target_dir in [('train', train_ds, TRAIN), ('test', test_ds, TEST)]:
    print(f'Writing {split_name}: {len(ds)} images')
    for idx, (img, y) in enumerate(tqdm(ds, desc=split_name)):
        img.save(target_dir / f'img_{idx:05d}_y{int(y)}.png')

print('Done.')
print('Train:', TRAIN)
print('Test :', TEST)
print('\nNOTE: the formal paper runs used the authors\' prepared CIFAR-10 PNG asset. ' 
      'For exact seed/client partition reproduction, use the same prepared asset when available.')
